import React, { useState, useEffect, useCallback } from 'react';
import { 
  FolderScanner 
} from './components/FolderScanner';
import { 
  MangaTable 
} from './components/MangaTable';
import { 
  NewVolumeModal 
} from './components/NewVolumeModal';
import { 
  SettingsModal 
} from './components/SettingsModal';
import { 
  ImportUrlsModal 
} from './components/ImportUrlsModal';
import { 
  ScriptGeneratorModal 
} from './components/ScriptGeneratorModal';
import {
  CrawlConsole
} from './components/CrawlConsole';
import {
  LiveLogViewer
} from './components/LiveLogViewer';
import {
  CheckpointCard
} from './components/CheckpointCard';
import {
  DlRawDatabaseTable
} from './components/DlRawDatabaseTable';
import {
  DlRawDetailModal
} from './components/DlRawDetailModal';
import {
  ParserPlayground
} from './components/ParserPlayground';
import {
  DownloadLogViewer
} from './components/DownloadLogViewer';
import { 
  LocalMangaItem, 
  MangaItem as DlRawMangaItem,
  NewVolumeInfo, 
  AppSettings,
  ScraperState,
  Checkpoint,
  CrawlSettings,
  CrawlLog,
  DownloadLogEntry
} from './types';
import { 
  pickAndScanMangaDirectory, 
  getMockSampleMangaList, 
  streamDownloadAndSaveToDirectory,
  ensureDirectoryPermission,
  resolveOrCreateSubfolder,
  isFileSystemAccessSupported
} from './utils/fileSystem';
import { parseMangaFilename, cleanFolderName } from './utils/mangaParser';
import { 
  FolderSync, 
  Settings, 
  Terminal, 
  FileCheck2, 
  CheckCircle2, 
  AlertCircle,
  ExternalLink,
  Sparkles,
  Link2,
  ChevronRight,
  Database,
  Layers,
  Wrench,
  Search,
  HardDrive,
  Download,
  Copy,
  Check,
  FolderCheck,
  FolderOpen,
  Package,
  X
} from 'lucide-react';

const DEFAULT_SETTINGS: AppSettings = {
  customProjectUrl: '',
  expectedPathPrefix: 'M:\\MangaS\\Manga\\',
  autoCheckOnScan: true,
  autoSaveToFolder: true,
  downloadFormat: 'cbz',
  searchSource: 'both',
  mockSimulationFallback: false,
  preferredHost: 'all',
};

export default function App() {
  // ナビゲーションタブ
  const [activeTab, setActiveTab] = useState<'local_sync' | 'dl_raw_db' | 'playground'>('local_sync');

  // ローカルPCマンガ管理ステート
  const [items, setItems] = useState<LocalMangaItem[]>([]);
  const [currentPath, setCurrentPath] = useState<string>('未選択 (サンプルデータ読込可能)');
  const [isScanning, setIsScanning] = useState(false);
  const [isCheckingNewReleases, setIsCheckingNewReleases] = useState(false);
  const [selectedMangaForModal, setSelectedMangaForModal] = useState<LocalMangaItem | null>(null);

  // ダウンロード実行ログ管理
  const [downloadLogs, setDownloadLogs] = useState<DownloadLogEntry[]>(() => {
    try {
      const saved = localStorage.getItem('auto_update_download_logs');
      return saved ? JSON.parse(saved) : [];
    } catch {
      return [];
    }
  });

  const addDownloadLog = (entry: DownloadLogEntry) => {
    setDownloadLogs((prev) => {
      const updated = [entry, ...prev.filter((l) => l.id !== entry.id).slice(0, 99)];
      try { localStorage.setItem('auto_update_download_logs', JSON.stringify(updated)); } catch {}
      return updated;
    });
  };

  const updateDownloadLog = (id: string, patch: Partial<DownloadLogEntry>) => {
    setDownloadLogs((prev) => {
      const updated = prev.map((l) => (l.id === id ? { ...l, ...patch } : l));
      try { localStorage.setItem('auto_update_download_logs', JSON.stringify(updated)); } catch {}
      return updated;
    });
  };

  const clearDownloadLogs = () => {
    setDownloadLogs([]);
    try { localStorage.removeItem('auto_update_download_logs'); } catch {}
    showToast('ダウンロードログをクリアしました', 'info');
  };

  // モーダル管理
  const [isSettingsOpen, setIsSettingsOpen] = useState(false);
  const [isScriptModalOpen, setIsScriptModalOpen] = useState(false);
  const [isImportModalOpen, setIsImportModalOpen] = useState(false);
  const [settings, setSettings] = useState<AppSettings>(DEFAULT_SETTINGS);
  const [toastMessage, setToastMessage] = useState<{ message: string; type: 'success' | 'error' | 'info' } | null>(null);
  const [showClarificationCard, setShowClarificationCard] = useState(true);

  // DL-RAW クローラー連携ステート (別PJ取り込み)
  const [scraperState, setScraperState] = useState<ScraperState | null>(null);
  const [activeCategory, setActiveCategory] = useState<'manga' | 'magazine'>('manga');
  const [checkpoint, setCheckpoint] = useState<Checkpoint | null>(null);
  const [previousCheckpoint, setPreviousCheckpoint] = useState<Checkpoint | null>(null);
  const [checkpointHistory, setCheckpointHistory] = useState<Checkpoint[]>([]);
  const [logs, setLogs] = useState<CrawlLog[]>([]);
  const [selectedDbManga, setSelectedDbManga] = useState<DlRawMangaItem | null>(null);
  const [refreshKey, setRefreshKey] = useState<number>(0);
  const [totalDbCount, setTotalDbCount] = useState<number>(0);

  // ルートフォルダハンドル (M:\MangaS\Manga)
  const [rootDirectoryHandle, setRootDirectoryHandle] = useState<any>(null);

  // 保存先選択モーダル
  const [isBatchDestinationModalOpen, setIsBatchDestinationModalOpen] = useState(false);
  const [batchTargetItem, setBatchTargetItem] = useState<{ item: LocalMangaItem; volumes: NewVolumeInfo[] } | null>(null);

  // 分割ストリーミング進行状況
  const [streamProgress, setStreamProgress] = useState<{
    isActive: boolean;
    status: 'downloading' | 'completed' | 'error';
    currentTitle: string;
    currentVolume: number;
    currentIndex: number;
    totalCount: number;
    receivedBytes: number;
    totalBytes: number;
    currentStep: string;
    savedToPcFolder: boolean;
    savedFolderPath?: string;
    completedList: Array<{
      title: string;
      volume: number;
      fileName: string;
      size: number;
      savedToPcFolder: boolean;
      folderPath?: string;
      blobUrl?: string;
    }>;
    errorMessage?: string;
  }>({
    isActive: false,
    status: 'downloading',
    currentTitle: '',
    currentVolume: 0,
    currentIndex: 0,
    totalCount: 0,
    receivedBytes: 0,
    totalBytes: 0,
    currentStep: '',
    savedToPcFolder: false,
    completedList: [],
  });

  const showToast = (message: string, type: 'success' | 'error' | 'info' = 'info') => {
    setToastMessage({ message, type });
    setTimeout(() => setToastMessage(null), 4000);
  };

  // ----------------------------------------------------
  // クローラー状態取得 & SSE 購読 (添付コード完全連携)
  // ----------------------------------------------------
  const fetchCrawlerStatus = useCallback(async (cat?: 'manga' | 'magazine') => {
    const targetCat = cat || activeCategory;
    try {
      const res = await fetch(`/api/status?category=${targetCat}`);
      const data = await res.json();
      if (data.success) {
        setScraperState(data.state);
        setCheckpoint(data.checkpoint);
        setPreviousCheckpoint(data.previousCheckpoint || data.checkpoint?.previous || null);
        if (data.checkpointHistory) setCheckpointHistory(data.checkpointHistory);
        if (data.mangaCount !== undefined) setTotalDbCount(data.mangaCount);
        if (data.state?.activeLog) setLogs(data.state.activeLog);
      }
    } catch (e) {
      console.warn('Crawler status fetch failed:', e);
    }
  }, [activeCategory]);

  useEffect(() => {
    fetchCrawlerStatus();

    const eventSource = new EventSource('/api/crawl/events');
    eventSource.onmessage = (e) => {
      try {
        const event = JSON.parse(e.data);
        if (event.type === 'init' || event.type === 'status_change') {
          setScraperState(event.payload);
          if (event.payload.checkpoint) setCheckpoint(event.payload.checkpoint);
        } else if (event.type === 'log') {
          setLogs((prev) => [event.payload, ...prev]);
        } else if (event.type === 'crawl_finished') {
          setScraperState(event.payload.state);
          setRefreshKey((k) => k + 1);
          showToast('DL-RAW巡回クロールが完了しました！', 'success');
        }
      } catch (err) {
        console.warn('SSE parse error:', err);
      }
    };

    return () => {
      eventSource.close();
    };
  }, [fetchCrawlerStatus]);

  // クロール操作
  const handleStartCrawl = async (crawlSettings: CrawlSettings) => {
    try {
      const res = await fetch('/api/crawl/start', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ ...crawlSettings, category: crawlSettings.category || activeCategory }),
      });
      const data = await res.json();
      if (data.success) {
        showToast(data.message, 'success');
        setScraperState(data.state);
      } else {
        showToast(data.message || '開始できませんでした', 'error');
      }
    } catch (e: any) {
      showToast(`クロール開始エラー: ${e.message}`, 'error');
    }
  };

  const handleStopCrawl = async () => {
    try {
      const res = await fetch('/api/crawl/stop', { method: 'POST' });
      const data = await res.json();
      showToast(data.message || 'クロールを停止しました', 'info');
      fetchCrawlerStatus();
    } catch (e: any) {
      showToast(`停止エラー: ${e.message}`, 'error');
    }
  };

  const handleResetCrawl = async () => {
    try {
      const res = await fetch('/api/crawl/reset', { method: 'POST' });
      const data = await res.json();
      showToast(data.message, 'info');
      fetchCrawlerStatus();
    } catch (e: any) {
      showToast(`リセットエラー: ${e.message}`, 'error');
    }
  };

  const handlePauseCrawl = async () => {
    await fetch('/api/crawl/pause', { method: 'POST' });
    fetchCrawlerStatus();
  };

  const handleResumeCrawl = async () => {
    await fetch('/api/crawl/resume', { method: 'POST' });
    fetchCrawlerStatus();
  };

  const handleExport = (format: 'json' | 'csv') => {
    window.location.href = `/api/export?format=${format}`;
    showToast(`${format.toUpperCase()}ファイルをダウンロードします`, 'success');
  };

  // ----------------------------------------------------
  // ローカルフォルダスキャン (M:\MangaS\Manga\)
  // ----------------------------------------------------
  const handlePickDirectory = async () => {
    setIsScanning(true);
    try {
      const result = await pickAndScanMangaDirectory();
      setRootDirectoryHandle(result.rootHandle);
      setItems(result.mangaList);
      setCurrentPath(result.rootName || 'M:\\MangaS\\Manga\\');
      showToast(`フォルダ走査完了: ${result.mangaList.length}作品を検出しました`, 'success');

      if (settings.autoCheckOnScan && result.mangaList.length > 0) {
        checkNewReleasesForItems(result.mangaList);
      }
    } catch (error: any) {
      if (error.name !== 'AbortError') {
        showToast(error.message || 'フォルダ選択に失敗しました', 'error');
      }
    } finally {
      setIsScanning(false);
    }
  };

  const handleLoadSampleData = () => {
    const sample = getMockSampleMangaList();
    setItems(sample);
    setCurrentPath('M:\\MangaS\\Manga (検証用サンプルデータ)');
    showToast(`検証用サンプルデータ (${sample.length}作品) を読み込みました`, 'success');
  };

  const handleManualFilesUpload = (files: FileList) => {
    const fileList = Array.from(files);
    if (fileList.length === 0) return;

    // 1. アップロードされたルートフォルダ名を取得して currentPath を即時反映！
    const firstRel = fileList[0]?.webkitRelativePath || '';
    let detectedPath = '';
    if (firstRel) {
      const parts = firstRel.split('/');
      const rootFolderName = parts[0];
      const lowerRoot = rootFolderName.toLowerCase();

      if (lowerRoot === 'manga' || lowerRoot === 'mangas') {
        const sub = parts.length > 2 ? parts[1] : '';
        detectedPath = sub ? `M:\\MangaS\\Manga\\${sub}\\` : `M:\\MangaS\\Manga\\`;
      } else if (lowerRoot === 'manga 1st' || lowerRoot === 'manga 2nd') {
        detectedPath = `M:\\MangaS\\Manga\\${rootFolderName}\\`;
      } else {
        const folderChain = parts.slice(0, Math.min(parts.length - 1, 2)).join('\\');
        detectedPath = folderChain ? `${folderChain}\\` : `${rootFolderName}\\`;
      }
    } else {
      detectedPath = `選択フォルダ (${fileList.length}ファイル)`;
    }
    setCurrentPath(detectedPath);

    // 2. ファイルを走査してマンガタイトル・巻数を高精度解析
    const map = new Map<string, LocalMangaItem>();
    fileList.forEach((f) => {
      const isMangaFile = /\.(cbz|zip|rar|cbr)$/i.test(f.name);
      if (!isMangaFile) return;

      const parts = f.webkitRelativePath ? f.webkitRelativePath.split('/') : [f.name];
      // 例: ["Manga", "manga 1st", "呪術廻戦", "呪術廻戦 第01巻.cbz"]
      // 例: ["manga 1st", "呪術廻戦", "呪術廻戦 第01巻.cbz"]
      const pathParts = parts.slice(0, -1);
      const folderTitle = pathParts.length > 0 ? pathParts[pathParts.length - 1] : 'Unknown';
      const category = pathParts.length > 1 ? pathParts[pathParts.length - 2] : 'manga 1st';

      // ファイル名から hogehoge と 巻数 を抽出
      const { title: parsedTitle, volume } = parseMangaFilename(f.name, folderTitle);
      const effectiveTitle = parsedTitle || cleanFolderName(folderTitle);
      const key = `${category}:::${folderTitle}`;

      if (!map.has(key)) {
        map.set(key, {
          id: key,
          folderName: folderTitle,
          mangaTitle: effectiveTitle,
          categoryFolder: category,
          subFolderPath: pathParts.join('/'),
          ownedVolumes: volume > 0 ? [volume] : [],
          maxVolume: volume,
          files: [{ name: f.name, volume, size: f.size }],
          status: 'idle',
          availableNewVolumes: [],
        });
      } else {
        const item = map.get(key)!;
        item.files.push({ name: f.name, volume, size: f.size });
        if (volume > 0 && !item.ownedVolumes.includes(volume)) {
          item.ownedVolumes.push(volume);
        }
        if (volume > item.maxVolume) {
          item.maxVolume = volume;
        }
        if (parsedTitle && parsedTitle.length > item.mangaTitle.length) {
          item.mangaTitle = parsedTitle;
        }
      }
    });

    const parsedList = Array.from(map.values()).map((item) => {
      item.ownedVolumes.sort((a, b) => a - b);
      item.files.sort((a, b) => a.volume - b.volume);
      return item;
    });

    setItems(parsedList);
    showToast(`フォルダ「${detectedPath}」から ${parsedList.length}作品を読み込みました`, 'success');

    if (settings.autoCheckOnScan && parsedList.length > 0) {
      checkNewReleasesForItems(parsedList);
    }
  };

  // ----------------------------------------------------
  // 新刊チェック (DL-RAW.SI ＆ クローラーDB連携)
  // ----------------------------------------------------
  const handleCheckSingle = async (targetItem: LocalMangaItem) => {
    setItems((prev) =>
      prev.map((i) => (i.id === targetItem.id ? { ...i, status: 'checking' } : i))
    );

    try {
      const res = await fetch('/api/search-manga', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          keyword: targetItem.mangaTitle,
          currentMaxVol: targetItem.maxVolume,
          preferredHost: settings.preferredHost,
        }),
      });

      const data = await res.json();
      let found: NewVolumeInfo[] = data.foundVolumes || [];

      // 検索結果 (実在の新刊のみ。シミュレーション設定OFF時は架空巻数を生成しない)
      if (found.length === 0 && settings.mockSimulationFallback && targetItem.maxVolume > 0) {
        const nextVol = targetItem.maxVolume + 1;
        found = [
          {
            volume: nextVol,
            title: `${targetItem.mangaTitle} 第${nextVol}巻`,
            source: 'DL-RAW.SI',
            selected: true,
            downloadLinks: [
              { host: 'katfile', url: `https://katfile.com/sim/${encodeURIComponent(targetItem.mangaTitle)}_v${nextVol}.rar`, label: 'KATFILE' },
              { host: 'rapidgator', url: `https://rapidgator.net/file/sim/${encodeURIComponent(targetItem.mangaTitle)}_v${nextVol}.rar`, label: 'RAPIDGATOR' },
              { host: 'rosefile', url: `https://rosefile.net/sim/${encodeURIComponent(targetItem.mangaTitle)}_v${nextVol}.rar`, label: 'ROSEFILE' },
            ],
          },
        ];
      }

      setItems((prev) =>
        prev.map((i) => {
          if (i.id === targetItem.id) {
            return {
              ...i,
              status: found.length > 0 ? 'has_updates' : 'up_to_date',
              availableNewVolumes: found,
              lastChecked: new Date().toLocaleTimeString(),
            };
          }
          return i;
        })
      );

      if (found.length > 0) {
        showToast(`${targetItem.mangaTitle}: 新刊 (第${found.map((v) => v.volume).join(', ')}巻) が見つかりました！`, 'success');
      } else {
        showToast(`${targetItem.mangaTitle}: 最新巻まで所持しています`, 'info');
      }
    } catch (err: any) {
      setItems((prev) =>
        prev.map((i) => (i.id === targetItem.id ? { ...i, status: 'error', errorMessage: err.message } : i))
      );
      showToast(`検索エラー: ${err.message}`, 'error');
    }
  };

  const checkNewReleasesForItems = async (itemsToCheck: LocalMangaItem[]) => {
    setIsCheckingNewReleases(true);
    let newReleaseCount = 0;

    for (const item of itemsToCheck) {
      try {
        const res = await fetch('/api/search-manga', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            keyword: item.mangaTitle,
            currentMaxVol: item.maxVolume,
            preferredHost: settings.preferredHost,
          }),
        });

        const data = await res.json();
        let found: NewVolumeInfo[] = data.foundVolumes || [];

        // シミュレーション設定がONの場合のみ検証用フォールバック
        if (found.length === 0 && settings.mockSimulationFallback && item.maxVolume > 0) {
          const nextVol = item.maxVolume + 1;
          found = [
            {
              volume: nextVol,
              title: `${item.mangaTitle} 第${nextVol}巻`,
              source: 'DL-RAW.SI',
              selected: true,
              downloadLinks: [
                { host: 'katfile', url: `https://katfile.com/sim/${encodeURIComponent(item.mangaTitle)}_v${nextVol}.rar`, label: 'KATFILE' },
                { host: 'rapidgator', url: `https://rapidgator.net/file/sim/${encodeURIComponent(item.mangaTitle)}_v${nextVol}.rar`, label: 'RAPIDGATOR' },
                { host: 'rosefile', url: `https://rosefile.net/sim/${encodeURIComponent(item.mangaTitle)}_v${nextVol}.rar`, label: 'ROSEFILE' },
              ],
            },
          ];
        }

        if (found.length > 0) {
          newReleaseCount += found.length;
        }

        setItems((prev) =>
          prev.map((i) => {
            if (i.id === item.id) {
              return {
                ...i,
                status: found.length > 0 ? 'has_updates' : 'up_to_date',
                availableNewVolumes: found,
                lastChecked: new Date().toLocaleTimeString(),
              };
            }
            return i;
          })
        );
      } catch (err) {
        // エラー時はステータスを維持
      }
    }

    setIsCheckingNewReleases(false);
    showToast(`一括チェック完了: 合計 ${newReleaseCount}冊の新刊を検出しました`, 'success');
  };

  // ----------------------------------------------------
  // 分割ストリーミングダウンロード ＆ PCフォルダ直接保存
  // ----------------------------------------------------
  const executeDownloadBatch = async (
    targetItems: Array<{ item: LocalMangaItem; volumes: NewVolumeInfo[] }>,
    customRootHandle?: any
  ) => {
    const activeRoot = customRootHandle || rootDirectoryHandle;
    const totalCount = targetItems.reduce((acc, t) => acc + t.volumes.length, 0);
    if (totalCount === 0) return;

    setStreamProgress({
      isActive: true,
      status: 'downloading',
      currentTitle: '',
      currentVolume: 0,
      currentIndex: 0,
      totalCount,
      receivedBytes: 0,
      totalBytes: 38 * 1024 * 1024,
      currentStep: 'ダウンロード準備中...',
      savedToPcFolder: !!activeRoot,
      completedList: [],
    });

    let overallIndex = 0;
    const completedList: Array<{
      title: string;
      volume: number;
      fileName: string;
      size: number;
      savedToPcFolder: boolean;
      folderPath?: string;
      blobUrl?: string;
    }> = [];
    const effectiveFormat = settings.downloadFormat || 'cbz';

    for (const { item, volumes } of targetItems) {
      let itemDirHandle = item.directoryHandle;
      if (!itemDirHandle && activeRoot) {
        try {
          itemDirHandle = await resolveOrCreateSubfolder(activeRoot, item.subFolderPath || `manga 1st/${item.folderName}`);
        } catch (e) {
          console.warn('Subfolder resolution error:', e);
        }
      }

      const addedVols: number[] = [];
      const savedFiles: Array<{ name: string; volume: number; size: number }> = [];

      for (const vol of volumes) {
        const volNum = vol.volume;
        const initialFileName = `${item.mangaTitle} 第${String(volNum).padStart(2, '0')}巻.${effectiveFormat}`;
        const logId = `dl-${Date.now()}-${overallIndex}-${volNum}`;

        const volumeExpectedSize = (item.files && item.files[0]?.size && item.files[0].size > 1000000)
          ? item.files[0].size
          : (38 * 1024 * 1024);

        addDownloadLog({
          id: logId,
          timestamp: new Date().toLocaleTimeString(),
          title: item.mangaTitle,
          volume: volNum,
          fileName: initialFileName,
          status: 'downloading',
          savedToPcFolder: !!itemDirHandle,
          destination: itemDirHandle ? (item.subFolderPath || item.folderName) : 'ブラウザ保存',
          message: itemDirHandle ? 'PCフォルダへ直接分割書き込み中...' : 'ブラウザ分割ストリーミング中...',
          downloadUrl: vol.downloadUrl,
        });

        setStreamProgress((prev) => ({
          ...prev,
          status: 'downloading',
          currentTitle: item.mangaTitle,
          currentVolume: volNum,
          currentIndex: overallIndex,
          receivedBytes: 0,
          totalBytes: volumeExpectedSize,
          currentStep: itemDirHandle
            ? `第${volNum}巻をPCフォルダへ分割書き込み中...`
            : `第${volNum}巻を分割ストリーミングダウンロード中...`,
          savedToPcFolder: !!itemDirHandle,
          savedFolderPath: item.subFolderPath,
        }));

        try {
          const result = await streamDownloadAndSaveToDirectory(
            itemDirHandle,
            initialFileName,
            {
              title: item.mangaTitle,
              volume: volNum,
              downloadUrl: vol.downloadUrl,
              format: effectiveFormat,
              size: volumeExpectedSize,
            },
            (received, total) => {
              setStreamProgress((prev) => ({
                ...prev,
                receivedBytes: received,
                totalBytes: total,
                currentStep: itemDirHandle
                  ? `第${volNum}巻をPCフォルダへ分割書き込み中 (${(received / (1024 * 1024)).toFixed(1)}MB / ${(total / (1024 * 1024)).toFixed(1)}MB)...`
                  : `第${volNum}巻をストリーミング中 (${(received / (1024 * 1024)).toFixed(1)}MB / ${(total / (1024 * 1024)).toFixed(1)}MB)...`,
              }));
            }
          );

          addedVols.push(volNum);
          savedFiles.push({
            name: result.fileName,
            volume: volNum,
            size: result.size,
          });

          completedList.push({
            title: item.mangaTitle,
            volume: volNum,
            fileName: result.fileName,
            size: result.size,
            savedToPcFolder: result.savedToPcFolder,
            folderPath: item.subFolderPath,
            blobUrl: result.blobUrl,
          });

          updateDownloadLog(logId, {
            status: 'success',
            size: result.size,
            message: result.savedToPcFolder ? 'PCフォルダへ直接保存完了' : 'ブラウザダウンロード完了',
          });
        } catch (err: any) {
          console.error(`Download error: ${item.mangaTitle} vol ${volNum}:`, err);
          updateDownloadLog(logId, {
            status: 'failed',
            error: err.message || '保存エラー',
            message: `保存失敗: ${err.message || 'エラー'}`,
          });
          showToast(`第${volNum}巻の保存エラー: ${err.message}`, 'error');
        }

        overallIndex++;
      }

      if (addedVols.length > 0) {
        const newMaxVol = Math.max(item.maxVolume, ...addedVols);
        setItems((prev) =>
          prev.map((i) => {
            if (i.id === item.id) {
              const updatedOwned = Array.from(new Set([...i.ownedVolumes, ...addedVols])).sort((a, b) => a - b);
              const remainingNew = i.availableNewVolumes.filter((v) => !addedVols.includes(v.volume));
              return {
                ...i,
                ownedVolumes: updatedOwned,
                maxVolume: newMaxVol,
                availableNewVolumes: remainingNew,
                status: remainingNew.length > 0 ? 'has_updates' : 'up_to_date',
                files: [...i.files, ...savedFiles],
              };
            }
            return i;
          })
        );
      }
    }

    // 完了ステートに更新 (自動では閉じない！)
    setStreamProgress((prev) => ({
      ...prev,
      status: 'completed',
      completedList,
      currentStep: '保存完了',
    }));

    showToast(`新刊 ${completedList.length}冊の分割保存が完了しました！`, 'success');
  };

  // ----------------------------------------------------
  // 全巻まとめ一括ZIPダウンロード (Chrome複数DLブロック完全回避)
  // ----------------------------------------------------
  const handleDownloadBatchZip = async (
    targetList: Array<{ item: LocalMangaItem; volumes: NewVolumeInfo[] }>
  ) => {
    const allVolumes: Array<{ title: string; volume: number; format: string; size: number }> = [];
    const effectiveFormat = settings.downloadFormat || 'cbz';

    targetList.forEach(({ item, volumes }) => {
      volumes.forEach((v) => {
        const volumeExpectedSize = (item.files && item.files[0]?.size && item.files[0].size > 1000000)
          ? item.files[0].size
          : (38 * 1024 * 1024);
        allVolumes.push({
          title: item.mangaTitle,
          volume: v.volume,
          format: effectiveFormat,
          size: volumeExpectedSize,
        });
      });
    });

    if (allVolumes.length === 0) return;

    const totalBytesEst = allVolumes.reduce((acc, v) => acc + v.size, 0);

    setStreamProgress({
      isActive: true,
      status: 'downloading',
      currentTitle: `全巻一括まとめ (${allVolumes.length}冊)`,
      currentVolume: 0,
      currentIndex: 0,
      totalCount: allVolumes.length,
      receivedBytes: 0,
      totalBytes: totalBytesEst,
      currentStep: `全${allVolumes.length}冊の実データアーカイブを1つのZIPにまとめて一括ダウンロード中...`,
      savedToPcFolder: false,
      completedList: [],
    });

    try {
      const res = await fetch('/api/batch-download-zip', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ items: allVolumes }),
      });

      if (!res.ok) {
        throw new Error(`一括ダウンロードエラー: ${res.statusText}`);
      }

      const reader = res.body?.getReader();
      const contentLength = Number(res.headers.get('content-length')) || totalBytesEst;
      let received = 0;
      const chunks: Uint8Array[] = [];

      if (reader) {
        while (true) {
          const { done, value } = await reader.read();
          if (done) break;
          if (value) {
            chunks.push(value);
            received += value.length;
            setStreamProgress((prev) => ({
              ...prev,
              receivedBytes: received,
              totalBytes: Math.max(contentLength, received),
              currentStep: `一括アーカイブを受信中 (${(received / (1024 * 1024)).toFixed(1)}MB / ${(contentLength / (1024 * 1024)).toFixed(1)}MB)...`,
            }));
          }
        }
      }

      const blob = new Blob(chunks as any, { type: 'application/zip' });
      const url = URL.createObjectURL(blob);
      const now = new Date();
      const dateStr = `${now.getFullYear()}${String(now.getMonth() + 1).padStart(2, '0')}${String(now.getDate()).padStart(2, '0')}`;
      const zipName = `新刊${allVolumes.length}冊_一括まとめ_${dateStr}.zip`;

      const a = document.createElement('a');
      a.href = url;
      a.download = zipName;
      document.body.appendChild(a);
      a.click();
      setTimeout(() => {
        try { document.body.removeChild(a); } catch {}
        URL.revokeObjectURL(url);
      }, 10000);

      const completedList = allVolumes.map((v) => ({
        title: v.title,
        volume: v.volume,
        fileName: `${v.title} 第${String(v.volume).padStart(2, '0')}巻.${v.format}`,
        size: v.size,
        savedToPcFolder: false,
        folderPath: '一括まとめZIP内',
      }));

      // Update state of owned volumes
      targetList.forEach(({ item, volumes }) => {
        const added = volumes.map((v) => v.volume);
        setItems((prev) =>
          prev.map((i) => {
            if (i.id === item.id) {
              const updatedOwned = Array.from(new Set([...i.ownedVolumes, ...added])).sort((a, b) => a - b);
              const remainingNew = i.availableNewVolumes.filter((v) => !added.includes(v.volume));
              const newMax = Math.max(i.maxVolume, ...added);
              return {
                ...i,
                ownedVolumes: updatedOwned,
                maxVolume: newMax,
                availableNewVolumes: remainingNew,
                status: remainingNew.length > 0 ? 'has_updates' : 'up_to_date',
              };
            }
            return i;
          })
        );
      });

      setStreamProgress((prev) => ({
        ...prev,
        status: 'completed',
        currentStep: 'まとめZIPダウンロード完了',
        completedList,
      }));

      showToast(`新刊${allVolumes.length}冊の一括まとめZIP (${(received / (1024 * 1024)).toFixed(1)}MB) を保存しました！`, 'success');
    } catch (err: any) {
      console.error('Batch download zip error:', err);
      setStreamProgress((prev) => ({
        ...prev,
        status: 'error',
        errorMessage: err.message,
      }));
      showToast(`一括まとめDL失敗: ${err.message}`, 'error');
    }
  };

  const handleDownloadAndSaveToFolder = async (
    targetItem: LocalMangaItem,
    selectedVolumes: NewVolumeInfo[]
  ) => {
    setSelectedMangaForModal(null);

    const hasHandle = targetItem.directoryHandle || rootDirectoryHandle;
    if (!hasHandle) {
      setBatchTargetItem({ item: targetItem, volumes: selectedVolumes });
      setIsBatchDestinationModalOpen(true);
      return;
    }

    await executeDownloadBatch([{ item: targetItem, volumes: selectedVolumes }]);
  };

  const handleBrowserDownloadOnly = async (
    targetItem: LocalMangaItem,
    selectedVolumes: NewVolumeInfo[]
  ) => {
    setSelectedMangaForModal(null);
    await executeDownloadBatch([{ item: targetItem, volumes: selectedVolumes }]);
  };

  const handleDownloadAllNewReleases = async () => {
    const itemsWithUpdates = items.filter((i) => i.availableNewVolumes.length > 0);
    if (itemsWithUpdates.length === 0) {
      showToast('ダウンロード対象の新刊が見つかりません', 'info');
      return;
    }

    setBatchTargetItem(null);
    setIsBatchDestinationModalOpen(true);
  };

  const handleImportAndSave = async (
    targetItem: LocalMangaItem,
    volumes: Array<{ volume: number; url: string; host: string }>
  ) => {
    const addedVols: number[] = [];
    const savedFiles: Array<{ name: string; volume: number; size: number }> = [];
    const effectiveFormat = settings.downloadFormat || 'cbz';

    const totalVols = volumes.length;
    let idx = 0;
    const completedItems: typeof streamProgress.completedList = [];

    for (const vol of volumes) {
      const volNum = vol.volume;
      const initialFileName = `${targetItem.mangaTitle} 第${String(volNum).padStart(2, '0')}巻.${effectiveFormat}`;

      let itemDir = targetItem.directoryHandle;
      if (!itemDir && rootDirectoryHandle) {
        try {
          itemDir = await resolveOrCreateSubfolder(rootDirectoryHandle, targetItem.subFolderPath || `manga 1st/${targetItem.folderName}`);
        } catch {}
      }

      const volumeExpectedSize = (targetItem.files && targetItem.files[0]?.size && targetItem.files[0].size > 1000000)
        ? targetItem.files[0].size
        : (38 * 1024 * 1024);

      setStreamProgress({
        isActive: true,
        status: 'downloading',
        currentTitle: targetItem.mangaTitle,
        currentVolume: volNum,
        currentIndex: idx,
        totalCount: totalVols,
        receivedBytes: 0,
        totalBytes: volumeExpectedSize,
        currentStep: `取り込みURLから第${volNum}巻を分割ストリーミング保存中...`,
        savedToPcFolder: !!itemDir,
        savedFolderPath: targetItem.subFolderPath,
        completedList: completedItems,
      });

      try {
        const result = await streamDownloadAndSaveToDirectory(
          itemDir,
          initialFileName,
          {
            title: targetItem.mangaTitle,
            volume: volNum,
            downloadUrl: vol.url,
            format: effectiveFormat,
            size: volumeExpectedSize,
          },
          (received, total) => {
            setStreamProgress((prev) => ({
              ...prev,
              receivedBytes: received,
              totalBytes: total,
              currentStep: itemDir
                ? `第${volNum}巻をPCフォルダへ分割書き込み中 (${(received / (1024 * 1024)).toFixed(1)}MB)...`
                : `第${volNum}巻をブラウザストリーミング中 (${(received / (1024 * 1024)).toFixed(1)}MB)...`,
            }));
          }
        );

        addedVols.push(volNum);
        savedFiles.push({
          name: result.fileName,
          volume: volNum,
          size: result.size,
        });

        completedItems.push({
          title: targetItem.mangaTitle,
          volume: volNum,
          fileName: result.fileName,
          size: result.size,
          savedToPcFolder: result.savedToPcFolder,
          folderPath: targetItem.subFolderPath,
          blobUrl: result.blobUrl,
        });
      } catch (err: any) {
        showToast(`第${volNum}巻の保存エラー: ${err.message}`, 'error');
      }

      idx++;
    }

    setStreamProgress((prev) => ({
      ...prev,
      status: 'completed',
      completedList: completedItems,
      currentStep: '保存完了',
    }));

    if (addedVols.length > 0) {
      const newMaxVol = Math.max(targetItem.maxVolume, ...addedVols);
      setItems((prev) =>
        prev.map((i) => {
          if (i.id === targetItem.id) {
            return {
              ...i,
              ownedVolumes: Array.from(new Set([...i.ownedVolumes, ...addedVols])).sort((a, b) => a - b),
              maxVolume: newMaxVol,
              files: [...i.files, ...savedFiles],
            };
          }
          return i;
        })
      );
      showToast(`取り込んだ新刊 ${addedVols.length}冊をPCへ分割保存しました！`, 'success');
    }

    setIsImportModalOpen(false);
  };

  const totalTitles = items.length;
  const totalFiles = items.reduce((acc, i) => acc + i.files.length, 0);
  const totalNewReleases = items.reduce((acc, i) => acc + i.availableNewVolumes.length, 0);

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 flex flex-col font-sans">
      {/* 分割ストリーミング書き込み進行中 / 完了モーダル */}
      {streamProgress.isActive && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/85 backdrop-blur-md animate-in fade-in duration-200">
          <div className="bg-slate-900 border border-indigo-500/50 rounded-2xl p-6 w-full max-w-lg shadow-2xl space-y-4">
            {/* ダウンロード進行中画面 */}
            {streamProgress.status === 'downloading' && (
              <>
                <div className="flex items-center justify-between gap-3">
                  <div className="flex items-center gap-3 min-w-0">
                    <div className="w-10 h-10 rounded-xl bg-indigo-600/20 text-indigo-400 border border-indigo-500/30 flex items-center justify-center animate-pulse shrink-0">
                      <Sparkles className="w-5 h-5" />
                    </div>
                    <div className="min-w-0">
                      <div className="flex items-center gap-2">
                        <h3 className="text-sm font-bold text-white truncate">
                          {streamProgress.currentTitle} 第{streamProgress.currentVolume}巻
                        </h3>
                        <span className="text-[10px] px-2 py-0.5 rounded-full bg-indigo-500/20 text-indigo-300 font-mono">
                          {streamProgress.currentIndex + 1} / {streamProgress.totalCount} 冊目
                        </span>
                      </div>
                      <p className="text-xs text-indigo-300 font-mono">
                        {streamProgress.savedToPcFolder
                          ? 'PCローカルフォルダへ分割書き込み中 (FileSystem API)'
                          : 'ブラウザ分割ストリーミングダウンロード中'}
                      </p>
                    </div>
                  </div>

                  <button
                    type="button"
                    onClick={() => setStreamProgress((prev) => ({ ...prev, isActive: false }))}
                    className="text-slate-400 hover:text-white p-1 rounded-lg hover:bg-slate-800 transition text-xs font-semibold shrink-0"
                  >
                    ✕ 中止
                  </button>
                </div>

                <div className="space-y-2">
                  <div className="flex justify-between text-xs font-mono">
                    <span className="text-slate-400 truncate max-w-[280px]">{streamProgress.currentStep}</span>
                    <span className="text-cyan-300 font-bold">
                      {streamProgress.totalBytes > 0
                        ? `${Math.min(100, Math.round((streamProgress.receivedBytes / streamProgress.totalBytes) * 100))}%`
                        : '処理中...'}
                    </span>
                  </div>

                  {/* プログレスバー */}
                  <div className="w-full h-3.5 rounded-full bg-slate-950 border border-slate-800 overflow-hidden p-0.5">
                    <div
                      className="h-full rounded-full bg-gradient-to-r from-indigo-500 via-cyan-400 to-emerald-400 transition-all duration-150"
                      style={{
                        width: `${streamProgress.totalBytes > 0 ? Math.min(100, Math.round((streamProgress.receivedBytes / streamProgress.totalBytes) * 100)) : 10}%`,
                      }}
                    />
                  </div>

                  <div className="flex justify-between text-[11px] text-slate-400 font-mono">
                    <span>書込済: {(streamProgress.receivedBytes / (1024 * 1024)).toFixed(1)} MB</span>
                    <span>予定サイズ: {(streamProgress.totalBytes / (1024 * 1024)).toFixed(1)} MB</span>
                  </div>
                </div>

                <div className="flex items-center justify-between pt-2 border-t border-slate-800/80 text-[11px] text-slate-400">
                  <span>※ メモリを圧迫しないようストリームを分割して直接PCへ逐次保存</span>
                  <span className="font-mono text-cyan-400">
                    全 {streamProgress.totalCount}冊 一括処理
                  </span>
                </div>
              </>
            )}

            {/* ダウンロード完了画面 */}
            {streamProgress.status === 'completed' && (
              <>
                <div className="flex items-center justify-between gap-3">
                  <div className="flex items-center gap-3">
                    <div className="w-10 h-10 rounded-xl bg-emerald-500/20 text-emerald-400 border border-emerald-500/30 flex items-center justify-center shrink-0">
                      <CheckCircle2 className="w-6 h-6" />
                    </div>
                    <div>
                      <h3 className="text-base font-bold text-white">
                        新刊 {streamProgress.completedList.length}冊の分割保存が完了しました！
                      </h3>
                      <p className="text-xs text-slate-400">
                        {streamProgress.savedToPcFolder
                          ? 'PCローカルフォルダへの書き込みが正常に完了しました'
                          : '各巻の実データアーカイブ（数十MB）を取得しました'}
                      </p>
                    </div>
                  </div>

                  <button
                    type="button"
                    onClick={() => setStreamProgress((prev) => ({ ...prev, isActive: false }))}
                    className="text-slate-400 hover:text-white p-1 rounded-lg hover:bg-slate-800 transition"
                  >
                    <X className="w-5 h-5" />
                  </button>
                </div>

                {/* 一括まとめZIP保存ボタン (Chrome複数DL制限回避) */}
                {streamProgress.completedList.length > 1 && (
                  <button
                    type="button"
                    onClick={() => {
                      const targets = streamProgress.completedList.map((c) => ({
                        item: { mangaTitle: c.title, files: [{ size: c.size }] } as any,
                        volumes: [{ volume: c.volume }] as any,
                      }));
                      handleDownloadBatchZip(targets);
                    }}
                    className="w-full py-2.5 px-4 rounded-xl bg-gradient-to-r from-indigo-600 via-indigo-500 to-cyan-600 hover:from-indigo-500 hover:to-cyan-500 text-white font-bold text-xs shadow-lg shadow-indigo-600/30 flex items-center justify-center gap-2 transition"
                  >
                    <Package className="w-4 h-4 text-cyan-200" />
                    <span>📦 全{streamProgress.completedList.length}冊を一括まとめZIPでダウンロード（Chrome制限なし）</span>
                  </button>
                )}

                {/* 保存済みファイルリスト */}
                <div className="space-y-2 max-h-60 overflow-y-auto pr-1">
                  {streamProgress.completedList.map((item, idx) => (
                    <div
                      key={idx}
                      className="bg-slate-950 border border-slate-800 rounded-xl p-3 flex items-center justify-between gap-3 text-xs"
                    >
                      <div className="min-w-0 space-y-0.5">
                        <div className="font-bold text-white truncate flex items-center gap-2">
                          <Check className="w-3.5 h-3.5 text-emerald-400 shrink-0" />
                          <span className="truncate">{item.fileName}</span>
                        </div>
                        <div className="text-[11px] text-slate-400 flex items-center gap-2 font-mono">
                          <span className="text-emerald-400 font-semibold">
                            {(item.size / (1024 * 1024)).toFixed(1)} MB
                          </span>
                          <span className="text-slate-600">|</span>
                          <span className="truncate text-cyan-300">
                            {item.savedToPcFolder ? `フォルダ: ${item.folderPath || 'Manga'}` : 'ブラウザ保存'}
                          </span>
                        </div>
                      </div>

                      <div className="shrink-0 flex items-center gap-1.5">
                        <a
                          href={`/api/download-file?title=${encodeURIComponent(item.title)}&volume=${item.volume}&format=${settings.downloadFormat || 'cbz'}&size=${item.size}`}
                          download={item.fileName}
                          className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-indigo-600/20 hover:bg-indigo-600 text-indigo-300 hover:text-white border border-indigo-500/30 text-xs font-semibold transition"
                          title="ブラウザから直接ダウンロード"
                        >
                          <Download className="w-3.5 h-3.5 text-cyan-400" />
                          <span>保存</span>
                        </a>
                      </div>
                    </div>
                  ))}
                </div>

                <div className="pt-2 border-t border-slate-800 flex items-center justify-between">
                  <span className="text-[11px] text-slate-400">
                    所持巻数とファイル一覧が自動更新されました
                  </span>
                  <button
                    type="button"
                    onClick={() => setStreamProgress((prev) => ({ ...prev, isActive: false }))}
                    className="px-5 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs shadow-lg shadow-emerald-600/30 transition"
                  >
                    完了して閉じる
                  </button>
                </div>
              </>
            )}
          </div>
        </div>
      )}

      {/* 保存先PCフォルダ選択＆一括DL確認モーダル */}
      {isBatchDestinationModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/85 backdrop-blur-md animate-in fade-in duration-200">
          <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6 w-full max-w-lg shadow-2xl space-y-4">
            <div className="flex items-center justify-between border-b border-slate-800 pb-4">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-xl bg-indigo-600/20 text-indigo-400 border border-indigo-500/30 flex items-center justify-center shrink-0">
                  <FolderOpen className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="text-base font-bold text-white">新刊の一括DL・保存</h3>
                  <p className="text-xs text-slate-400">保存方法を選択してください</p>
                </div>
              </div>
              <button
                type="button"
                onClick={() => setIsBatchDestinationModalOpen(false)}
                className="text-slate-400 hover:text-white p-1 rounded-lg hover:bg-slate-800 transition"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* ダウンロード対象サマリー */}
            <div className="bg-slate-950 border border-slate-800 rounded-xl p-3.5 space-y-2">
              <div className="text-xs font-semibold text-slate-300">
                ダウンロード対象の新刊一覧:
              </div>
              <div className="space-y-1.5 max-h-40 overflow-y-auto pr-1">
                {(batchTargetItem
                  ? [batchTargetItem]
                  : items.filter((i) => i.availableNewVolumes.length > 0).map((i) => ({ item: i, volumes: i.availableNewVolumes }))
                ).map(({ item, volumes }) => (
                  <div key={item.id} className="text-xs flex items-center justify-between text-slate-300 bg-slate-900/60 p-2 rounded-lg border border-slate-800/80">
                    <span className="font-semibold truncate max-w-[260px]">{item.mangaTitle}</span>
                    <span className="font-mono text-cyan-300 font-bold shrink-0">
                      第{volumes.map((v) => v.volume).join(', ')}巻 ({volumes.length}冊)
                    </span>
                  </div>
                ))}
              </div>
            </div>

            <div className="space-y-2.5 pt-1">
              <button
                type="button"
                onClick={async () => {
                  try {
                    if (!isFileSystemAccessSupported()) {
                      showToast('お使いのブラウザはフォルダ直接保存に対応していません。全巻まとめZIP保存をご利用ください。', 'error');
                      return;
                    }
                    // @ts-ignore
                    const handle = await window.showDirectoryPicker({ mode: 'readwrite' });
                    setRootDirectoryHandle(handle);
                    setCurrentPath(handle.name || 'M:\\MangaS\\Manga\\');
                    setIsBatchDestinationModalOpen(false);

                    if (batchTargetItem) {
                      await executeDownloadBatch([batchTargetItem], handle);
                    } else {
                      const itemsWithUpdates = items.filter((i) => i.availableNewVolumes.length > 0);
                      const targets = itemsWithUpdates.map((i) => ({ item: i, volumes: i.availableNewVolumes }));
                      await executeDownloadBatch(targets, handle);
                    }
                  } catch (err: any) {
                    if (err.name !== 'AbortError') {
                      showToast(`フォルダ選択エラー: ${err.message}`, 'error');
                    }
                  }
                }}
                className="w-full py-3 px-4 rounded-xl bg-gradient-to-r from-emerald-600 to-teal-500 hover:from-emerald-500 hover:to-teal-400 text-white font-bold text-xs shadow-lg shadow-emerald-600/30 flex items-center justify-center gap-2 transition"
              >
                <FolderCheck className="w-4 h-4" />
                <span>① PCフォルダを選択して直接保存（M:\MangaS\Manga 等へ全冊自動配置）[推奨]</span>
              </button>

              <button
                type="button"
                onClick={async () => {
                  setIsBatchDestinationModalOpen(false);
                  const targets = batchTargetItem
                    ? [batchTargetItem]
                    : items.filter((i) => i.availableNewVolumes.length > 0).map((i) => ({ item: i, volumes: i.availableNewVolumes }));
                  await handleDownloadBatchZip(targets);
                }}
                className="w-full py-3 px-4 rounded-xl bg-gradient-to-r from-indigo-600 to-cyan-600 hover:from-indigo-500 hover:to-cyan-500 text-white font-bold text-xs shadow-lg shadow-indigo-600/30 flex items-center justify-center gap-2 transition"
              >
                <Package className="w-4 h-4 text-cyan-200" />
                <span>② 全巻まとめZIPで一括保存（Chrome複数DL制限なし・全冊1つのZIPでDL）[推奨]</span>
              </button>

              <button
                type="button"
                onClick={async () => {
                  setIsBatchDestinationModalOpen(false);
                  if (batchTargetItem) {
                    await executeDownloadBatch([batchTargetItem]);
                  } else {
                    const itemsWithUpdates = items.filter((i) => i.availableNewVolumes.length > 0);
                    const targets = itemsWithUpdates.map((i) => ({ item: i, volumes: i.availableNewVolumes }));
                    await executeDownloadBatch(targets);
                  }
                }}
                className="w-full py-2.5 px-4 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 font-medium text-xs border border-slate-700 flex items-center justify-center gap-2 transition"
              >
                <Download className="w-3.5 h-3.5 text-slate-400" />
                <span>③ 各巻を個別にブラウザ保存（完了画面から全巻個別保存可能）</span>
              </button>

              <button
                type="button"
                onClick={() => {
                  const vols = batchTargetItem
                    ? batchTargetItem.volumes
                    : items.flatMap((i) => i.availableNewVolumes);
                  const links = vols.map((v) => v.downloadUrl || v.downloadLinks?.[0]?.url || '').filter(Boolean);
                  if (links.length > 0) {
                    navigator.clipboard.writeText(links.join('\n'));
                    showToast(`${links.length}件のDLリンクをコピーしました`, 'success');
                  }
                }}
                className="w-full py-2 px-4 rounded-xl bg-slate-900 hover:bg-slate-800 text-slate-400 hover:text-slate-200 text-xs flex items-center justify-center gap-2 transition"
              >
                <Copy className="w-3.5 h-3.5" />
                <span>全リンクURLをコピー (JDownloader等へ貼り付け)</span>
              </button>
            </div>
          </div>
        </div>
      )}

      {/* トースト通知 */}
      {toastMessage && (
        <div className="fixed bottom-6 right-6 z-50 flex items-center gap-2.5 px-4 py-3 rounded-xl bg-slate-900 border border-indigo-500/50 shadow-2xl animate-in slide-in-from-bottom duration-200">
          {toastMessage.type === 'success' && <CheckCircle2 className="w-4 h-4 text-emerald-400" />}
          {toastMessage.type === 'error' && <AlertCircle className="w-4 h-4 text-rose-400" />}
          {toastMessage.type === 'info' && <Sparkles className="w-4 h-4 text-cyan-400" />}
          <span className="text-xs font-medium text-slate-200">{toastMessage.message}</span>
        </div>
      )}

      {/* ヘッダー */}
      <header className="border-b border-slate-800 bg-slate-900/90 backdrop-blur-md sticky top-0 z-40">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-3.5 flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-gradient-to-tr from-indigo-600 to-cyan-500 flex items-center justify-center text-white shadow-lg shadow-indigo-500/25">
              <FolderSync className="w-5 h-5" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h1 className="font-bold text-base text-white tracking-tight">AutoUpdateMangaFolder</h1>
                <span className="px-2 py-0.5 rounded text-[10px] font-semibold bg-indigo-500/20 text-indigo-300 border border-indigo-500/30">
                  DL-RAW.SI 連携版
                </span>
                <span className="px-1.5 py-0.5 rounded text-[10px] font-mono bg-emerald-500/10 text-emerald-400 border border-emerald-500/20">
                  実データ分割保存
                </span>
              </div>
              <p className="text-xs text-slate-400">
                M:\MangaS\Manga 自動スキャン ＆ 新刊分割ストリーミング保存
              </p>
            </div>
          </div>

          {/* ナビゲーションタブ */}
          <div className="flex items-center gap-1.5 bg-slate-950 p-1 rounded-xl border border-slate-800">
            <button
              onClick={() => setActiveTab('local_sync')}
              className={`flex items-center gap-1.5 px-3.5 py-1.5 rounded-lg text-xs font-semibold transition ${
                activeTab === 'local_sync'
                  ? 'bg-indigo-600 text-white shadow-sm'
                  : 'text-slate-400 hover:text-slate-200 hover:bg-slate-900'
              }`}
            >
              <HardDrive className="w-3.5 h-3.5" />
              <span>ローカルマンガ更新</span>
              {totalNewReleases > 0 && (
                <span className="px-1.5 py-0.2 rounded-full bg-amber-400 text-slate-950 text-[10px] font-bold">
                  {totalNewReleases}
                </span>
              )}
            </button>

            <button
              onClick={() => setActiveTab('dl_raw_db')}
              className={`flex items-center gap-1.5 px-3.5 py-1.5 rounded-lg text-xs font-semibold transition ${
                activeTab === 'dl_raw_db'
                  ? 'bg-indigo-600 text-white shadow-sm'
                  : 'text-slate-400 hover:text-slate-200 hover:bg-slate-900'
              }`}
            >
              <Database className="w-3.5 h-3.5" />
              <span>DL-RAW クローラーDB</span>
              {totalDbCount > 0 && (
                <span className="text-[10px] text-indigo-300 font-mono">
                  ({totalDbCount})
                </span>
              )}
            </button>

            <button
              onClick={() => setActiveTab('playground')}
              className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-semibold transition ${
                activeTab === 'playground'
                  ? 'bg-indigo-600 text-white shadow-sm'
                  : 'text-slate-400 hover:text-slate-200 hover:bg-slate-900'
              }`}
            >
              <Wrench className="w-3.5 h-3.5" />
              <span>解析Playground</span>
            </button>
          </div>

          {/* 右上ユーティリティ */}
          <div className="flex items-center gap-2">
            <button
              onClick={() => setIsImportModalOpen(true)}
              className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs font-medium border border-slate-700 transition"
              title="外部URL（Katfile/Rapidgator等）を直接貼り付けて一括取り込み"
            >
              <Link2 className="w-3.5 h-3.5 text-cyan-400" />
              <span className="hidden sm:inline">URL直接取り込み</span>
            </button>

            <button
              onClick={() => setIsScriptModalOpen(true)}
              className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs font-medium border border-slate-700 transition"
              title="Windows用ローカル同期スクリプトをダウンロード"
            >
              <Terminal className="w-3.5 h-3.5 text-emerald-400" />
              <span className="hidden sm:inline">同期スクリプト</span>
            </button>

            <button
              onClick={() => setIsSettingsOpen(true)}
              className="p-2 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 border border-slate-700 transition"
              title="設定"
            >
              <Settings className="w-4 h-4" />
            </button>
          </div>
        </div>
      </header>

      {/* メインコンテンツ */}
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6 flex-1 space-y-6">
        {/* TAB 1: ローカルマンガ更新マネージャー (M:\MangaS\Manga) */}
        {activeTab === 'local_sync' && (
          <div className="space-y-6">
            {/* 説明カード */}
            {showClarificationCard && (
              <div className="bg-gradient-to-r from-indigo-950/60 via-slate-900 to-cyan-950/40 border border-indigo-500/30 rounded-2xl p-4 sm:p-5 relative overflow-hidden shadow-lg">
                <button
                  onClick={() => setShowClarificationCard(false)}
                  className="absolute top-3 right-3 text-slate-500 hover:text-slate-300 p-1"
                >
                  ✕
                </button>
                <div className="flex items-start gap-3">
                  <div className="p-2 rounded-xl bg-indigo-500/20 text-indigo-400 shrink-0 mt-0.5">
                    <Sparkles className="w-5 h-5" />
                  </div>
                  <div className="space-y-2 text-xs">
                    <div className="flex items-center gap-2">
                      <h2 className="font-bold text-sm text-white">AutoUpdateMangaFolder の動作仕様</h2>
                      <span className="px-2 py-0.5 rounded bg-emerald-500/20 text-emerald-300 font-semibold text-[10px]">
                        実データ(数十MB) 分割処理保存対応
                      </span>
                    </div>
                    <p className="text-slate-300 leading-relaxed">
                      １．<strong>M:\MangaS\Manga\</strong> 以下の <code>manga 1st\"MangaTitle"\"hogehoge 第xx巻.cbz"</code> をスキャン<br/>
                      ２．各ファイルの <strong>マンガタイトル (hogehoge)</strong> と <strong>最大巻数 (xx)</strong> を自動解析<br/>
                      ３．DL-RAWの検索結果から最大巻数より大きな新刊をフィルター抽出<br/>
                      ４．実データ（数十MBの <code>.rar</code> / <code>.zip</code>）を <strong>分割ストリーミング処理</strong> でPCフォルダへ直接保存
                    </p>
                    <div className="flex flex-wrap items-center gap-3 pt-1">
                      <button
                        onClick={() => setIsImportModalOpen(true)}
                        className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-indigo-600 hover:bg-indigo-500 text-white font-semibold text-xs transition"
                      >
                        <Link2 className="w-3.5 h-3.5" />
                        <span>DLリンクを直接貼り付けて一括保存</span>
                      </button>
                      <button
                        onClick={() => setIsSettingsOpen(true)}
                        className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs font-medium border border-slate-700 transition"
                      >
                        <span>保存形式（rar / zip / cbz）を設定</span>
                        <ChevronRight className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  </div>
                </div>
              </div>
            )}

            {/* フォルダ選択＆統計コントロール */}
            <FolderScanner
              currentPath={currentPath}
              totalTitles={totalTitles}
              totalFiles={totalFiles}
              newReleasesCount={totalNewReleases}
              isScanning={isScanning}
              onPickDirectory={handlePickDirectory}
              onLoadSampleData={handleLoadSampleData}
              onManualFilesUpload={handleManualFilesUpload}
              onCheckAllNewReleases={() => checkNewReleasesForItems(items)}
              onDownloadAllNewReleases={handleDownloadAllNewReleases}
              isCheckingNewReleases={isCheckingNewReleases}
              onManualPathChange={setCurrentPath}
            />

            {/* マンガ一覧テーブル */}
            <MangaTable
              items={items}
              onCheckSingle={handleCheckSingle}
              onDownloadNewVolume={(item, vol) => handleDownloadAndSaveToFolder(item, [vol])}
              onOpenVolumeModal={(item) => setSelectedMangaForModal(item)}
            />

            {/* ダウンロード実行ログ＆成否・エラー追跡 */}
            <DownloadLogViewer
              logs={downloadLogs}
              onClearLogs={clearDownloadLogs}
            />
          </div>
        )}

        {/* TAB 2: DL-RAW.SI 巡回クローラー & 全DB (取り込み連携) */}
        {activeTab === 'dl_raw_db' && (
          <div className="space-y-6">
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
              <div className="lg:col-span-2 space-y-6">
                <CrawlConsole
                  state={scraperState}
                  checkpoint={checkpoint}
                  previousCheckpoint={previousCheckpoint}
                  activeCategory={activeCategory}
                  onCategoryChange={(newCat) => {
                    setActiveCategory(newCat);
                    fetchCrawlerStatus(newCat);
                  }}
                  onStart={handleStartCrawl}
                  onStop={handleStopCrawl}
                  onReset={handleResetCrawl}
                  onPause={handlePauseCrawl}
                  onResume={handleResumeCrawl}
                  onClearDb={async () => {
                    await fetch('/api/manga/clear', { method: 'DELETE' });
                    setRefreshKey((k) => k + 1);
                    fetchCrawlerStatus();
                  }}
                />
                <LiveLogViewer logs={logs} state={scraperState} onClearLogs={() => setLogs([])} />
              </div>

              <div className="space-y-6">
                <CheckpointCard
                  checkpoint={checkpoint}
                  previousCheckpoint={previousCheckpoint}
                  checkpointHistory={checkpointHistory}
                  activeCategory={activeCategory}
                  onClearCheckpoint={async () => {
                    await fetch(`/api/checkpoint?category=${activeCategory}`, { method: 'DELETE' });
                    fetchCrawlerStatus();
                  }}
                  onRollbackCheckpoint={async () => {
                    await fetch(`/api/checkpoint/rollback?category=${activeCategory}`, { method: 'POST' });
                    fetchCrawlerStatus();
                  }}
                />
              </div>
            </div>

            {/* 全データベーステーブル */}
            <div className="pt-2">
              <DlRawDatabaseTable
                refreshKey={refreshKey}
                onSelectItem={(dbItem) => setSelectedDbManga(dbItem)}
                onExport={handleExport}
                onImportSuccess={() => {
                  setRefreshKey((k) => k + 1);
                  fetchCrawlerStatus();
                }}
                showNotification={showToast}
              />
            </div>
          </div>
        )}

        {/* TAB 3: 解析 Playground */}
        {activeTab === 'playground' && (
          <div className="space-y-6">
            <ParserPlayground />
          </div>
        )}
      </main>

      {/* フッター */}
      <footer className="border-t border-slate-900 bg-slate-950 py-4 text-center text-xs text-slate-500">
        <p>AutoUpdateMangaFolder &bull; M:\MangaS\Manga 自動更新マネージャー ＆ DL-RAW.SI 取り込み連携</p>
      </footer>

      {/* 新刊ダウンロードモーダル */}
      {selectedMangaForModal && (
        <NewVolumeModal
          item={selectedMangaForModal}
          onClose={() => setSelectedMangaForModal(null)}
          onDownloadAndSave={handleDownloadAndSaveToFolder}
          onBrowserDownloadOnly={handleBrowserDownloadOnly}
        />
      )}

      {/* 外部DLリンク取り込みモーダル */}
      {isImportModalOpen && (
        <ImportUrlsModal
          items={items}
          onClose={() => setIsImportModalOpen(false)}
          onImportAndSave={handleImportAndSave}
        />
      )}

      {/* 設定モーダル */}
      {isSettingsOpen && (
        <SettingsModal
          settings={settings}
          onSave={(newSettings) => {
            setSettings(newSettings);
            setIsSettingsOpen(false);
            showToast('設定を保存しました', 'success');
          }}
          onClose={() => setIsSettingsOpen(false)}
        />
      )}

      {/* スクリプトモーダル */}
      {isScriptModalOpen && (
        <ScriptGeneratorModal
          targetPath={settings.expectedPathPrefix}
          onClose={() => setIsScriptModalOpen(false)}
        />
      )}

      {/* DL-RAW DB 詳細モーダル */}
      {selectedDbManga && (
        <DlRawDetailModal
          item={selectedDbManga}
          onClose={() => setSelectedDbManga(null)}
          onSetCheckpoint={(item) => {
            fetch('/api/checkpoint', {
              method: 'POST',
              headers: { 'Content-Type': 'application/json' },
              body: JSON.stringify({
                title: item.title,
                rawTitle: item.latestPostTitle,
                maxVolume: item.maxVolume,
                displayVolume: item.displayVolume,
                url: item.latestUrl,
                page: 1,
                savedAt: new Date().toISOString(),
                category: item.category,
              }),
            }).then(() => {
              showToast(`チェックポイントに設定しました: ${item.title}`, 'success');
              fetchCrawlerStatus();
            });
          }}
        />
      )}
    </div>
  );
}
