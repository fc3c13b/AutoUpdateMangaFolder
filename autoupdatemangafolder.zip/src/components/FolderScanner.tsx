import React, { useRef, useState, useEffect } from 'react';
import { 
  FolderOpen, 
  FolderCheck, 
  Sparkles, 
  AlertCircle, 
  Layers, 
  FileArchive, 
  DownloadCloud, 
  CheckCircle2,
  HardDrive
} from 'lucide-react';
import { isFileSystemAccessSupported } from '../utils/fileSystem';

interface FolderScannerProps {
  currentPath: string;
  totalTitles: number;
  totalFiles: number;
  newReleasesCount: number;
  isScanning: boolean;
  onPickDirectory: () => void;
  onLoadSampleData: () => void;
  onManualFilesUpload: (files: FileList) => void;
  onCheckAllNewReleases: () => void;
  onDownloadAllNewReleases: () => void;
  isCheckingNewReleases: boolean;
  onManualPathChange?: (newPath: string) => void;
}

export const FolderScanner: React.FC<FolderScannerProps> = ({
  currentPath,
  totalTitles,
  totalFiles,
  newReleasesCount,
  isScanning,
  onPickDirectory,
  onLoadSampleData,
  onManualFilesUpload,
  onCheckAllNewReleases,
  onDownloadAllNewReleases,
  isCheckingNewReleases,
  onManualPathChange,
}) => {
  const fileInputRef = useRef<HTMLInputElement>(null);
  const isSupported = isFileSystemAccessSupported();
  const [isEditingPath, setIsEditingPath] = useState(false);
  const [tempPath, setTempPath] = useState(currentPath);

  useEffect(() => {
    setTempPath(currentPath);
  }, [currentPath]);

  const handleFallbackClick = () => {
    if (fileInputRef.current) {
      fileInputRef.current.value = '';
      fileInputRef.current.click();
    }
  };

  const handleFileInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files.length > 0) {
      onManualFilesUpload(e.target.files);
    }
    if (e.target) {
      e.target.value = '';
    }
  };

  return (
    <div className="bg-slate-900 border border-slate-800 rounded-2xl p-5 shadow-xl">
      {/* フォルダ選択バナー */}
      <div className="flex flex-col lg:flex-row items-start lg:items-center justify-between gap-4 pb-5 border-b border-slate-800/80">
        <div className="space-y-1">
          <div className="flex items-center gap-2">
            <span className="p-1.5 rounded-lg bg-indigo-500/10 text-indigo-400 border border-indigo-500/20">
              <HardDrive className="w-4 h-4" />
            </span>
            <span className="text-sm font-semibold text-slate-300">
              対象ディレクトリ:
            </span>
            {isEditingPath ? (
              <form
                onSubmit={(e) => {
                  e.preventDefault();
                  if (onManualPathChange && tempPath.trim()) {
                    onManualPathChange(tempPath.trim());
                  }
                  setIsEditingPath(false);
                }}
                className="flex items-center gap-1.5"
              >
                <input
                  type="text"
                  value={tempPath}
                  onChange={(e) => setTempPath(e.target.value)}
                  className="text-xs bg-slate-950 px-2.5 py-1 rounded-md text-cyan-300 font-mono border border-indigo-500 focus:outline-none"
                  autoFocus
                />
                <button
                  type="submit"
                  className="px-2 py-1 rounded bg-indigo-600 text-white text-[11px] font-semibold hover:bg-indigo-500 transition"
                >
                  決定
                </button>
                <button
                  type="button"
                  onClick={() => setIsEditingPath(false)}
                  className="px-2 py-1 rounded bg-slate-800 text-slate-300 text-[11px] hover:bg-slate-700 transition"
                >
                  取消
                </button>
              </form>
            ) : (
              <div className="flex items-center gap-1.5">
                <code className="text-xs bg-slate-950 px-2.5 py-1 rounded-md text-cyan-300 font-mono border border-slate-800">
                  {currentPath || 'M:\\MangaS\\Manga\\manga 1st\\'}
                </code>
                {onManualPathChange && (
                  <button
                    type="button"
                    onClick={() => {
                      setTempPath(currentPath || 'M:\\MangaS\\Manga\\manga 1st\\');
                      setIsEditingPath(true);
                    }}
                    className="p-1 rounded text-slate-400 hover:text-white hover:bg-slate-800 text-[10px] transition"
                    title="パスを手動編集"
                  >
                    ✏️ 編集
                  </button>
                )}
              </div>
            )}
          </div>
          <p className="text-xs text-slate-400">
            形式: <code className="text-slate-300">manga 1st\"MangaTitle"\"hogehoge 第xx巻.cbz"</code> を自動検出・巻数解析します
          </p>
        </div>

        {/* コントロールボタン */}
        <div className="flex flex-wrap items-center gap-2.5">
          <input
            ref={fileInputRef}
            type="file"
            // @ts-ignore
            webkitdirectory="true"
            directory="true"
            multiple
            className="hidden"
            onChange={handleFileInputChange}
          />
          <button
            onClick={handleFallbackClick}
            className="inline-flex items-center gap-2 px-4 py-2.5 rounded-xl bg-gradient-to-r from-indigo-600 to-indigo-500 hover:from-indigo-500 hover:to-indigo-400 text-white text-sm font-semibold shadow-lg shadow-indigo-600/30 transition active:scale-[0.98]"
            title="PCのフォルダを選択してマンガ・巻数を読み込み"
          >
            <FolderOpen className="w-4 h-4" />
            <span>フォルダを選択して読み込み</span>
          </button>

          {isSupported && (
            <button
              onClick={onPickDirectory}
              disabled={isScanning}
              className="inline-flex items-center gap-2 px-3.5 py-2.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-white text-xs font-medium border border-slate-700/80 transition disabled:opacity-50"
              title="FileSystem APIでフォルダを選択 (M:\MangaS\Manga)"
            >
              <HardDrive className="w-3.5 h-3.5 text-cyan-400" />
              <span>{isScanning ? '同期中...' : 'PCフォルダ同期 (M:\\)'}</span>
            </button>
          )}

          <button
            onClick={onLoadSampleData}
            className="inline-flex items-center gap-2 px-3.5 py-2.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-white text-xs font-medium border border-slate-700/80 transition"
            title="サンプルマンガ（呪術廻戦、SPY×FAMILY等）で動作を試す"
          >
            <Sparkles className="w-3.5 h-3.5 text-amber-400" />
            <span>サンプルデータで確認</span>
          </button>
        </div>
      </div>

      {/* 統計＆一括アクション */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 pt-5">
        <div className="bg-slate-950/60 border border-slate-800/80 rounded-xl p-3.5 flex items-center gap-3">
          <div className="w-10 h-10 rounded-lg bg-indigo-500/10 border border-indigo-500/20 flex items-center justify-center text-indigo-400 shrink-0">
            <Layers className="w-5 h-5" />
          </div>
          <div>
            <div className="text-xl font-bold text-white tracking-tight">{totalTitles}</div>
            <div className="text-[11px] font-medium text-slate-400">マンガタイトル数</div>
          </div>
        </div>

        <div className="bg-slate-950/60 border border-slate-800/80 rounded-xl p-3.5 flex items-center gap-3">
          <div className="w-10 h-10 rounded-lg bg-cyan-500/10 border border-cyan-500/20 flex items-center justify-center text-cyan-400 shrink-0">
            <FileArchive className="w-5 h-5" />
          </div>
          <div>
            <div className="text-xl font-bold text-white tracking-tight">{totalFiles}</div>
            <div className="text-[11px] font-medium text-slate-400">所持CBZファイル数</div>
          </div>
        </div>

        <div className="bg-slate-950/60 border border-slate-800/80 rounded-xl p-3.5 flex items-center gap-3">
          <div className={`w-10 h-10 rounded-lg ${newReleasesCount > 0 ? 'bg-amber-500/20 text-amber-400 border border-amber-500/30 animate-pulse' : 'bg-emerald-500/10 text-emerald-400 border border-emerald-500/20'} flex items-center justify-center shrink-0`}>
            {newReleasesCount > 0 ? <AlertCircle className="w-5 h-5" /> : <CheckCircle2 className="w-5 h-5" />}
          </div>
          <div>
            <div className={`text-xl font-bold ${newReleasesCount > 0 ? 'text-amber-400' : 'text-slate-200'} tracking-tight`}>
              {newReleasesCount}
            </div>
            <div className="text-[11px] font-medium text-slate-400">未所持の新刊巻数</div>
          </div>
        </div>

        <div className="bg-slate-950/60 border border-slate-800/80 rounded-xl p-2.5 flex items-center justify-between gap-2">
          {newReleasesCount > 0 ? (
            <div className="w-full flex flex-col gap-1.5">
              <button
                onClick={onDownloadAllNewReleases}
                className="w-full py-2 px-2 rounded-lg bg-emerald-600 hover:bg-emerald-500 text-white font-semibold text-xs flex items-center justify-center gap-1.5 shadow-md shadow-emerald-600/30 transition active:scale-[0.98]"
              >
                <DownloadCloud className="w-4 h-4" />
                <span>新刊 {newReleasesCount}冊を一括DL保存</span>
              </button>
              <button
                onClick={onCheckAllNewReleases}
                disabled={isCheckingNewReleases}
                className="w-full py-1 px-2 rounded-md bg-slate-800 hover:bg-slate-700 text-slate-300 text-[11px] font-medium border border-slate-700 flex items-center justify-center gap-1 transition disabled:opacity-40"
                title="DL-RAWの新刊情報を再検索して更新"
              >
                <FolderCheck className={`w-3 h-3 ${isCheckingNewReleases ? 'animate-spin text-indigo-400' : ''}`} />
                <span>{isCheckingNewReleases ? '再検索中...' : 'DL-RAW再検索'}</span>
              </button>
            </div>
          ) : (
            <button
              onClick={onCheckAllNewReleases}
              disabled={isCheckingNewReleases || totalTitles === 0}
              className="w-full h-full py-2 px-2 rounded-lg bg-indigo-600/20 hover:bg-indigo-600/30 text-indigo-300 hover:text-white border border-indigo-500/30 font-semibold text-xs flex flex-col items-center justify-center gap-1 transition disabled:opacity-40"
            >
              <FolderCheck className={`w-4 h-4 ${isCheckingNewReleases ? 'animate-spin text-indigo-400' : ''}`} />
              <span>{isCheckingNewReleases ? '新刊検索中...' : 'DL-RAW一括検索'}</span>
            </button>
          )}
        </div>
      </div>
    </div>
  );
};
