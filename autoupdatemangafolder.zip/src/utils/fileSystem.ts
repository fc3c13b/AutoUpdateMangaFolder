import { LocalMangaItem, MangaFile } from '../types';
import { parseMangaFilename, cleanFolderName } from './mangaParser';

/**
 * File System Access API をサポートしているか判定
 */
export function isFileSystemAccessSupported(): boolean {
  return typeof window !== 'undefined' && 'showDirectoryPicker' in window;
}

/**
 * ディレクトリピッカーを開いてフォルダを走査
 */
export async function pickAndScanMangaDirectory(): Promise<{
  mangaList: LocalMangaItem[];
  rootName: string;
  rootHandle: any;
}> {
  if (!isFileSystemAccessSupported()) {
    throw new Error('お使いのブラウザはFile System Access APIに対応していません。Chrome、Edge、またはOperaをご利用ください。');
  }

  // @ts-ignore
  const rootHandle = await window.showDirectoryPicker({
    mode: 'readwrite',
  });

  const mangaList = await scanDirectoryRecursively(rootHandle, '');
  return {
    mangaList,
    rootName: rootHandle.name,
    rootHandle,
  };
}

/**
 * 再帰的にディレクトリをスキャン
 * 構造:
 * - root / "manga 1st" / "MangaTitle" / "hogehoge 第xx巻.cbz"
 * または
 * - root / "MangaTitle" / "hogehoge 第xx巻.cbz"
 */
export async function scanDirectoryRecursively(
  dirHandle: any,
  currentPath: string
): Promise<LocalMangaItem[]> {
  const mangaItemsMap = new Map<string, LocalMangaItem>();

  async function traverse(currentHandle: any, pathParts: string[]) {
    // @ts-ignore
    for await (const [name, handle] of currentHandle.entries()) {
      if (handle.kind === 'directory') {
        // 次の階層へ
        await traverse(handle, [...pathParts, name]);
      } else if (handle.kind === 'file') {
        const isMangaFile = /\.(cbz|zip|rar|cbr)$/i.test(name);
        if (!isMangaFile) continue;

        // 階層情報
        // pathParts: 例 ['manga 1st', 'ONE PIECE'] または ['ONE PIECE']
        const category = pathParts.length > 1 ? pathParts[0] : 'default';
        const folderTitle = pathParts.length > 0 ? pathParts[pathParts.length - 1] : 'Unknown';
        
        // ファイル名からタイトルと巻数をパース
        const { title: parsedTitle, volume } = parseMangaFilename(name, folderTitle);
        const effectiveTitle = parsedTitle || cleanFolderName(folderTitle);

        // キーは タイトル または (フォルダパス + タイトル)
        const key = `${category}:::${folderTitle}`;

        const fileObj: MangaFile = {
          name,
          volume,
          size: 0,
          handle,
        };

        try {
          const fileData = await handle.getFile();
          fileObj.size = fileData.size;
          fileObj.lastModified = fileData.lastModified;
        } catch {
          // ignore
        }

        if (!mangaItemsMap.has(key)) {
          mangaItemsMap.set(key, {
            id: key,
            folderName: folderTitle,
            mangaTitle: effectiveTitle,
            categoryFolder: category,
            subFolderPath: pathParts.join('/'),
            ownedVolumes: [volume].filter(v => v > 0),
            maxVolume: volume,
            files: [fileObj],
            directoryHandle: currentHandle, // そのファイルの親ディレクトリハンドル
            status: 'idle',
            availableNewVolumes: [],
          });
        } else {
          const item = mangaItemsMap.get(key)!;
          item.files.push(fileObj);
          if (volume > 0 && !item.ownedVolumes.includes(volume)) {
            item.ownedVolumes.push(volume);
          }
          if (volume > item.maxVolume) {
            item.maxVolume = volume;
          }
          // もし抽出タイトルがより具体的であれば更新
          if (parsedTitle && parsedTitle.length > item.mangaTitle.length) {
            item.mangaTitle = parsedTitle;
          }
        }
      }
    }
  }

  await traverse(dirHandle, currentPath ? [currentPath] : []);

  // ソートして配列で返却
  const result: LocalMangaItem[] = [];
  for (const item of mangaItemsMap.values()) {
    item.ownedVolumes.sort((a, b) => a - b);
    item.files.sort((a, b) => a.volume - b.volume);
    result.push(item);
  }

  // タイトル順でソート
  result.sort((a, b) => a.mangaTitle.localeCompare(b.mangaTitle, 'ja'));

  return result;
}

/**
 * 取得したデータをPCのローカルフォルダに直接保存する（チャンク分割ストリーミング対応）
 */
export async function saveFileToDirectory(
  dirHandle: any,
  fileName: string,
  dataBlob: Blob
): Promise<boolean> {
  if (!dirHandle || typeof dirHandle.getFileHandle !== 'function') {
    throw new Error('有効なフォルダハンドルが存在しません。');
  }

  try {
    if (dirHandle.requestPermission) {
      const permission = await dirHandle.requestPermission({ mode: 'readwrite' });
      if (permission !== 'granted') {
        throw new Error('フォルダへの書き込み権限が拒否されました。');
      }
    }

    const fileHandle = await dirHandle.getFileHandle(fileName, { create: true });
    const writable = await fileHandle.createWritable();
    await writable.write(dataBlob);
    await writable.close();
    return true;
  } catch (error: any) {
    console.error('File save error:', error);
    throw error;
  }
}

/**
 * フォルダの書き込み権限を安全に確認・リクエスト（User Activation考慮）
 */
export async function ensureDirectoryPermission(dirHandle: any): Promise<boolean> {
  if (!dirHandle) return false;
  try {
    if (typeof dirHandle.queryPermission === 'function') {
      const status = await dirHandle.queryPermission({ mode: 'readwrite' });
      if (status === 'granted') return true;
    }
    if (typeof dirHandle.requestPermission === 'function') {
      const req = await dirHandle.requestPermission({ mode: 'readwrite' });
      return req === 'granted';
    }
  } catch (e) {
    console.warn('Permission query/request failed:', e);
  }
  return true;
}

/**
 * ルートフォルダから階層（例: "manga 1st/呪術廻戦"）を再帰的に取得または作成
 */
export async function resolveOrCreateSubfolder(rootHandle: any, subFolderPath: string): Promise<any> {
  if (!rootHandle) return null;
  const parts = subFolderPath.split(/[\/\\]/).filter(Boolean);
  let current = rootHandle;
  for (const part of parts) {
    try {
      current = await current.getDirectoryHandle(part, { create: true });
    } catch (e) {
      console.warn(`Failed to resolve or create folder segment: ${part}`, e);
      return null;
    }
  }
  return current;
}

/**
 * ブラウザ直接ダウンロード:
 * 添付コードの handleExport (window.location / direct link) と同様に
 * サーバーの /api/download-file から直接ダウンロード
 */
/**
 * ブラウザ直接ダウンロード:
 * Chromeのiframe制約（URL遷移リンクによる別タブオープン・エラー）を完全に防止。
 * fetchでチャンク分割ストリームを受信し、Blobからダウンロードを実行（別タブを開かない）。
 */
export async function triggerBrowserFileDownload(
  title: string,
  volume: number,
  format: string = 'cbz',
  downloadUrl: string = '',
  onProgress?: (receivedBytes: number, totalBytes: number) => void,
  size?: number
): Promise<{ fileName: string; size: number; savedToPcFolder: boolean; blobUrl?: string }> {
  const effectiveFormat = format === 'rar' ? 'rar' : (format === 'zip' ? 'zip' : 'cbz');
  const fileName = `${title} 第${String(volume).padStart(2, '0')}巻.${effectiveFormat}`;

  return streamDownloadAndSaveToDirectory(
    null,
    fileName,
    { title, volume, format: effectiveFormat, downloadUrl, size },
    onProgress
  );
}

/**
 * 分割処理ストリーミング保存:
 * 1. PCフォルダハンドル (dirHandle) がある場合:
 *    ブラウザのFile System Access APIを使い、PCのローカルフォルダに直接チャンク逐次書き込み
 * 2. PCフォルダハンドルが無い（ブラウザ保存モード）場合:
 *    ストリームをメモリチャンクに逐次受信（プログレスバー更新）し、完了時にBlobからダウンロード保存
 *    ※ Chromeで別タブが開いてエラーになる現象を完全に防止（a.href = blobUrl）
 */
export async function streamDownloadAndSaveToDirectory(
  dirHandle: any,
  fileName: string,
  downloadPayload: { title: string; volume: number; downloadUrl?: string; format?: string; size?: number },
  onProgress?: (receivedBytes: number, totalBytes: number) => void
): Promise<{ fileName: string; size: number; blobUrl?: string; savedToPcFolder: boolean }> {
  let writable: any = null;
  let finalFileName = fileName;
  let savedToPcFolder = false;

  // 1. PCフォルダ直接保存の試行
  if (dirHandle && typeof dirHandle.getFileHandle === 'function') {
    try {
      await ensureDirectoryPermission(dirHandle);
      const fileHandle = await dirHandle.getFileHandle(fileName, { create: true });
      writable = await fileHandle.createWritable();
      savedToPcFolder = true;
    } catch (permErr: any) {
      console.warn('Direct file handle failed, will fallback to browser direct download:', permErr.message);
      writable = null;
      savedToPcFolder = false;
    }
  }

  // 2. ストリーミングリクエスト（同一オリジン内でフェッチ）
  const res = await fetch('/api/stream-download', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(downloadPayload),
  });

  if (!res.ok) {
    if (writable) {
      try { await writable.abort(); } catch {}
    }
    let errDetail = `${res.status} ${res.statusText}`;
    try {
      const errJson = await res.json();
      if (errJson.error) errDetail = errJson.error;
    } catch {}
    throw new Error(`ダウンロード処理失敗: ${errDetail}`);
  }

  const contentLength = Number(res.headers.get('content-length')) || downloadPayload.size || (38 * 1024 * 1024);
  const contentDisposition = res.headers.get('content-disposition');
  if (contentDisposition) {
    // 1. UTF-8指定を最優先で取得
    const utf8Match = contentDisposition.match(/filename\*=(?:UTF-8''|utf-8'')([^;]+)/i);
    if (utf8Match && utf8Match[1]) {
      try {
        finalFileName = decodeURIComponent(utf8Match[1].trim().replace(/^["']|["']$/g, ''));
      } catch {}
    } else {
      // 2. 通常のfilename属性
      const normalMatch = contentDisposition.match(/filename="?([^";]+)"?/i);
      if (normalMatch && normalMatch[1]) {
        const val = normalMatch[1].trim();
        // manga_v等の簡易名は採用せず、渡された正式名称を保持
        if (!val.startsWith('manga_v') && !val.startsWith('download')) {
          try {
            finalFileName = decodeURIComponent(val);
          } catch {
            finalFileName = val;
          }
        }
      }
    }
  }

  // 初期通知
  if (onProgress) {
    onProgress(0, contentLength);
  }

  // 3. ストリーム読み込み＆チャンク逐次書き込み
  const reader = res.body?.getReader();
  if (!reader) {
    throw new Error('ストリームリーダーの取得に失敗しました');
  }

  let receivedBytes = 0;
  const memoryChunks: Uint8Array[] = [];
  let lastProgressUpdate = 0;

  try {
    while (true) {
      const { done, value } = await reader.read();
      if (done) break;
      if (value) {
        if (writable) {
          await writable.write(value);
        } else {
          memoryChunks.push(value);
        }
        receivedBytes += value.length;

        const now = Date.now();
        if (now - lastProgressUpdate > 30 || receivedBytes >= contentLength) {
          lastProgressUpdate = now;
          if (onProgress) {
            onProgress(receivedBytes, Math.max(contentLength, receivedBytes));
          }
        }
      }
    }

    if (writable) {
      await writable.close();
    }

    if (onProgress) {
      onProgress(receivedBytes, Math.max(contentLength, receivedBytes));
    }

    let blobUrl: string | undefined = undefined;
    if (!writable && memoryChunks.length > 0) {
      const mimeType = finalFileName.endsWith('.rar')
        ? 'application/x-rar-compressed'
        : 'application/zip';
      const blob = new Blob(memoryChunks as any, { type: mimeType });
      blobUrl = URL.createObjectURL(blob);

      // Chromeのiframe sandbox環境で安全にDLを実行 (別タブを開かないBlobダウンロード)
      const a = document.createElement('a');
      a.href = blobUrl;
      a.download = finalFileName;
      document.body.appendChild(a);
      a.click();
      setTimeout(() => {
        try { document.body.removeChild(a); } catch {}
        if (blobUrl) URL.revokeObjectURL(blobUrl);
      }, 10000);

      // ブラウザの自動ダウンロード抑制（複数同時DLブロック）を回避するためウェイト
      await new Promise((resolve) => setTimeout(resolve, 500));
    }

    return {
      fileName: finalFileName,
      size: receivedBytes,
      blobUrl,
      savedToPcFolder,
    };
  } catch (streamErr: any) {
    if (writable) {
      try { await writable.abort(); } catch {}
    }
    throw streamErr;
  }
}

/**
 * ローカルPC上の実ファイル（数十MBの .rar / .zip）をチャンク分割ストリーミングで
 * 対象マンガフォルダへコピー・保存
 */
export async function copyLocalFileChunked(
  dirHandle: any,
  file: File,
  targetFileName: string,
  onProgress?: (receivedBytes: number, totalBytes: number) => void
): Promise<number> {
  const fileHandle = await dirHandle.getFileHandle(targetFileName, { create: true });
  const writable = await fileHandle.createWritable();

  const chunkSize = 2 * 1024 * 1024; // 2MBごとに分割処理
  let offset = 0;

  while (offset < file.size) {
    const slice = file.slice(offset, offset + chunkSize);
    const buffer = await slice.arrayBuffer();
    await writable.write(buffer);
    offset += buffer.byteLength;
    if (onProgress) {
      onProgress(offset, file.size);
    }
  }

  await writable.close();
  return file.size;
}

/**
 * サンプルデータの生成（動作検証・プレビュー用）
 */
export function getMockSampleMangaList(): LocalMangaItem[] {
  return [
    {
      id: 'manga 1st:::そうだ、売国しよう ～天才王子の赤字国家再生術～',
      folderName: 'そうだ、売国しよう ～天才王子の赤字国家再生術～',
      mangaTitle: 'そうだ、売国しよう ～天才王子の赤字国家再生術～',
      categoryFolder: 'manga 1st',
      subFolderPath: 'manga 1st/そうだ、売国しよう ～天才王子の赤字国家再生術～',
      ownedVolumes: Array.from({ length: 18 }, (_, i) => i + 1),
      maxVolume: 18,
      files: Array.from({ length: 18 }, (_, i) => ({
        name: `そうだ、売国しよう ～天才王子の赤字国家再生術～ 第${String(i + 1).padStart(2, '0')}巻.cbz`,
        volume: i + 1,
        size: 38000000,
      })),
      status: 'idle',
      availableNewVolumes: [
        {
          volume: 19,
          title: 'そうだ、売国しよう ～天才王子の赤字国家再生術～ 第19巻',
          source: 'DL-RAW.SI',
          selected: true,
          downloadLinks: [
            { host: 'katfile', url: 'https://katfile.com/sim/SoudaBaikoku_v19.rar', label: 'KATFILE' },
            { host: 'rapidgator', url: 'https://rapidgator.net/file/sim/SoudaBaikoku_v19.rar', label: 'RAPIDGATOR' },
          ],
        },
      ],
    },
    {
      id: 'manga 1st:::呪術廻戦',
      folderName: '呪術廻戦',
      mangaTitle: '呪術廻戦',
      categoryFolder: 'manga 1st',
      subFolderPath: 'manga 1st/呪術廻戦',
      ownedVolumes: [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27],
      maxVolume: 27,
      files: Array.from({ length: 27 }, (_, i) => ({
        name: `呪術廻戦 第${String(i + 1).padStart(2, '0')}巻.cbz`,
        volume: i + 1,
        size: 78000000 + (i * 1234567) % 30000000,
      })),
      status: 'idle',
      availableNewVolumes: [],
    },
    {
      id: 'manga 1st:::SPY×FAMILY',
      folderName: 'SPY×FAMILY',
      mangaTitle: 'SPY×FAMILY',
      categoryFolder: 'manga 1st',
      subFolderPath: 'manga 1st/SPY×FAMILY',
      ownedVolumes: [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13],
      maxVolume: 13,
      files: Array.from({ length: 13 }, (_, i) => ({
        name: `SPY×FAMILY 第${String(i + 1).padStart(2, '0')}巻.cbz`,
        volume: i + 1,
        size: 85000000 + (i * 987654) % 25000000,
      })),
      status: 'idle',
      availableNewVolumes: [],
    },
    {
      id: 'manga 1st:::葬送のフリーレン',
      folderName: '葬送のフリーレン',
      mangaTitle: '葬送のフリーレン',
      categoryFolder: 'manga 1st',
      subFolderPath: 'manga 1st/葬送のフリーレン',
      ownedVolumes: [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12],
      maxVolume: 12,
      files: Array.from({ length: 12 }, (_, i) => ({
        name: `葬送のフリーレン 第${String(i + 1).padStart(2, '0')}巻.cbz`,
        volume: i + 1,
        size: 92000000 + (i * 543210) % 20000000,
      })),
      status: 'idle',
      availableNewVolumes: [],
    },
    {
      id: 'manga 1st:::チェンソーマン',
      folderName: 'チェンソーマン',
      mangaTitle: 'チェンソーマン',
      categoryFolder: 'manga 1st',
      subFolderPath: 'manga 1st/チェンソーマン',
      ownedVolumes: [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17],
      maxVolume: 17,
      files: Array.from({ length: 17 }, (_, i) => ({
        name: `チェンソーマン 第${String(i + 1).padStart(2, '0')}巻.cbz`,
        volume: i + 1,
        size: 82000000,
      })),
      status: 'idle',
      availableNewVolumes: [],
    },
    {
      id: 'manga 1st:::怪獣8号',
      folderName: '怪獣8号',
      mangaTitle: '怪獣8号',
      categoryFolder: 'manga 1st',
      subFolderPath: 'manga 1st/怪獣8号',
      ownedVolumes: [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14],
      maxVolume: 14,
      files: Array.from({ length: 14 }, (_, i) => ({
        name: `怪獣8号 第${String(i + 1).padStart(2, '0')}巻.cbz`,
        volume: i + 1,
        size: 91000000,
      })),
      status: 'idle',
      availableNewVolumes: [],
    },
  ];
}
