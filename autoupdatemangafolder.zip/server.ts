import express from 'express';
import dotenv from 'dotenv';
import path from 'path';
import { fileURLToPath } from 'url';
import { Readable } from 'stream';
import { createServer as createViteServer } from 'vite';
import { scraperInstance } from './server/scraper.js';
import { Storage } from './server/storage.js';
import { parsePostTitle, normalizeTitle } from './src/utils/parser.js';
import { MANGA_DATA_BASE } from './server/sampleData.js';

dotenv.config();

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

async function startServer() {
  const app = express();
  const PORT = Number(process.env.PORT) || 3000;

  app.use(express.json({ limit: '100mb' }));
  app.use(express.urlencoded({ extended: true, limit: '100mb' }));

  // ==========================================
  // 1. DL-RAW.SI 巡回クローラー & DB API群 (添付コード連携)
  // ==========================================

  // クローラー状態取得
  app.get('/api/status', (req, res) => {
    const category = (req.query.category as string) || scraperInstance.getCrawlCategory() || 'manga';
    const state = scraperInstance.getState();
    const fullList = Storage.getMangaList();
    const mangaCount = fullList.length;
    const mangaCategoryCount = fullList.filter((m) => (m.category || 'manga') === 'manga').length;
    const magazineCategoryCount = fullList.filter((m) => (m.category || 'manga') === 'magazine').length;
    const checkpoint = Storage.getCheckpoint(category);
    const previousCheckpoint = Storage.getPreviousCheckpoint(category);
    const checkpointHistory = Storage.getCheckpointHistory(category);
    const stats = Storage.getStats();
    res.json({
      success: true,
      category,
      state,
      mangaCount,
      categoryCounts: {
        all: mangaCount,
        manga: mangaCategoryCount,
        magazine: magazineCategoryCount,
      },
      checkpoint,
      previousCheckpoint,
      checkpointHistory,
      stats,
    });
  });

  // クロール開始
  app.post('/api/crawl/start', async (req, res) => {
    const {
      startPage = 1,
      maxPages = 10,
      waitMs = 1500,
      stopOnCheckpoint = true,
      mode = 'live',
      baseUrl,
      category = 'manga',
    } = req.body;
    const started = await scraperInstance.start({
      category,
      startPage: Number(startPage),
      maxPages: Number(maxPages),
      waitMs: Number(waitMs),
      stopOnCheckpoint: Boolean(stopOnCheckpoint),
      mode: mode || 'live',
      baseUrl: baseUrl || (category === 'magazine' ? 'https://dl-raw.si/category/magazine' : 'https://dl-raw.si/category/manga'),
    });

    res.json({
      success: started,
      message: started ? 'クロールを開始しました' : 'すでにクロールが実行中です',
      state: scraperInstance.getState(),
    });
  });

  // クロール停止
  app.post('/api/crawl/stop', (req, res) => {
    scraperInstance.stop();
    res.json({
      success: true,
      message: 'クロールを停止しました',
      state: scraperInstance.getState(),
    });
  });

  // クロールリセット
  app.post('/api/crawl/reset', (req, res) => {
    scraperInstance.reset();
    res.json({
      success: true,
      message: 'クロール状態を待機状態にリセットしました',
      state: scraperInstance.getState(),
    });
  });

  // クロール一時停止
  app.post('/api/crawl/pause', (req, res) => {
    scraperInstance.pause();
    res.json({ success: true, message: '一時停止しました' });
  });

  // クロール再開
  app.post('/api/crawl/resume', (req, res) => {
    scraperInstance.resume();
    res.json({ success: true, message: '再開しました' });
  });

  // SSE リアルタイムログストリーム
  app.get('/api/crawl/events', (req, res) => {
    res.setHeader('Content-Type', 'text/event-stream');
    res.setHeader('Cache-Control', 'no-cache');
    res.setHeader('Connection', 'keep-alive');
    res.flushHeaders?.();

    res.write(`data: ${JSON.stringify({ type: 'init', payload: scraperInstance.getState() })}\n\n`);

    const unsubscribe = scraperInstance.subscribe((event) => {
      res.write(`data: ${JSON.stringify(event)}\n\n`);
    });

    req.on('close', () => {
      unsubscribe();
    });
  });

  // 全漫画リスト取得 (ページネーション・検索・ソート)
  app.get('/api/manga', (req, res) => {
    const fullList = Storage.getMangaList();
    const totalAll = fullList.length;
    const {
      q,
      category,
      sort = 'updated-desc',
      page = '1',
      limit = '50',
      all = 'false',
    } = req.query as {
      q?: string;
      category?: string;
      sort?: string;
      page?: string;
      limit?: string;
      all?: string;
    };

    let list = fullList;

    if (q) {
      const query = q.toLowerCase().trim();
      list = list.filter(
        (item) =>
          item.title.toLowerCase().includes(query) ||
          item.latestPostTitle.toLowerCase().includes(query) ||
          (item.author && item.author.toLowerCase().includes(query))
      );
    }

    if (category && category !== 'all') {
      const targetCat = category.toLowerCase().trim();
      list = list.filter((item) => (item.category || 'manga').toLowerCase().trim() === targetCat);
    }

    list.sort((a, b) => {
      if (sort === 'volume-desc') return b.maxVolume - a.maxVolume;
      if (sort === 'volume-asc') return a.maxVolume - b.maxVolume;
      if (sort === 'title-asc') return a.title.localeCompare(b.title, 'ja');
      if (sort === 'title-desc') return b.title.localeCompare(a.title, 'ja');
      if (sort === 'updated-asc') return new Date(a.lastUpdatedAt).getTime() - new Date(b.lastUpdatedAt).getTime();
      return new Date(b.lastUpdatedAt).getTime() - new Date(a.lastUpdatedAt).getTime();
    });

    const totalFiltered = list.length;

    if (all === 'true') {
      return res.json({
        success: true,
        total: totalFiltered,
        totalAll,
        page: 1,
        limit: totalFiltered,
        totalPages: 1,
        items: list,
      });
    }

    const pageNum = Math.max(1, parseInt(page, 10) || 1);
    const limitNum = Math.max(10, Math.min(500, parseInt(limit, 10) || 50));
    const totalPages = Math.max(1, Math.ceil(totalFiltered / limitNum));
    const validPage = Math.min(pageNum, totalPages);
    const startIndex = (validPage - 1) * limitNum;
    const paginatedItems = list.slice(startIndex, startIndex + limitNum);

    res.json({
      success: true,
      total: totalFiltered,
      totalAll,
      page: validPage,
      limit: limitNum,
      totalPages,
      items: paginatedItems,
    });
  });

  // 単一アイテム削除
  app.delete('/api/manga/:id', (req, res) => {
    const { id } = req.params;
    let list = Storage.getMangaList();
    const filtered = list.filter((item) => item.id !== id);
    Storage.saveMangaList(filtered);
    res.json({ success: true, remaining: filtered.length });
  });

  // 全データ消去
  app.delete('/api/manga/clear', (req, res) => {
    Storage.clearAll();
    res.json({ success: true, message: 'データベースを初期化しました' });
  });

  // チェックポイント
  app.get('/api/checkpoint', (req, res) => {
    const category = (req.query.category as string) || scraperInstance.getCrawlCategory() || 'manga';
    res.json({
      success: true,
      category,
      checkpoint: Storage.getCheckpoint(category),
      previousCheckpoint: Storage.getPreviousCheckpoint(category),
      history: Storage.getCheckpointHistory(category),
    });
  });

  app.post('/api/checkpoint', (req, res) => {
    const cp = req.body;
    const category = cp?.category || (req.query.category as string) || scraperInstance.getCrawlCategory() || 'manga';
    Storage.saveCheckpoint(cp, category);
    res.json({
      success: true,
      category,
      checkpoint: Storage.getCheckpoint(category),
      previousCheckpoint: Storage.getPreviousCheckpoint(category),
      history: Storage.getCheckpointHistory(category),
    });
  });

  app.post('/api/checkpoint/rollback', (req, res) => {
    const category = (req.body?.category as string) || (req.query.category as string) || scraperInstance.getCrawlCategory() || 'manga';
    const result = Storage.rollbackCheckpoint(category);
    res.json({
      success: result.success,
      category,
      checkpoint: result.checkpoint,
      previousCheckpoint: Storage.getPreviousCheckpoint(category),
      history: Storage.getCheckpointHistory(category),
      message: result.success ? '一つ前のチェックポイントに復元しました' : '復元可能な以前のチェックポイントがありません',
    });
  });

  app.delete('/api/checkpoint', (req, res) => {
    const category = (req.query.category as string) || (req.body?.category as string) || scraperInstance.getCrawlCategory() || 'manga';
    Storage.saveCheckpoint(null, category);
    res.json({ success: true, message: `チェックポイント (${category}) を削除しました` });
  });

  // パーステスト
  app.post('/api/parse-test', (req, res) => {
    const { text } = req.body;
    if (!text) {
      return res.status(400).json({ error: 'Text is required' });
    }
    const result = parsePostTitle(text);
    res.json({ success: true, result });
  });

  // エクスポート CSV / JSON
  app.get('/api/export', (req, res) => {
    const format = req.query.format || 'json';
    const list = Storage.getMangaList();

    if (format === 'csv') {
      const header = 'タイトル,最大巻数,カテゴリ,作者,最新投稿タイトル,最新URL,初回登録日時,最終更新日時\n';
      const rows = list
        .map((item) => {
          const escapeCsv = (str?: string) => `"${(str || '').replace(/"/g, '""')}"`;
          return [
            escapeCsv(item.title),
            item.maxVolume,
            escapeCsv(item.category),
            escapeCsv(item.author || ''),
            escapeCsv(item.latestPostTitle),
            escapeCsv(item.latestUrl),
            escapeCsv(item.firstSeenAt),
            escapeCsv(item.lastUpdatedAt),
          ].join(',');
        })
        .join('\n');

      res.setHeader('Content-Type', 'text/csv; charset=utf-8');
      res.setHeader('Content-Disposition', 'attachment; filename="dl_raw_manga_list.csv"');
      return res.send('\uFEFF' + header + rows);
    }

    res.setHeader('Content-Type', 'application/json');
    res.setHeader('Content-Disposition', 'attachment; filename="dl_raw_manga_list.json"');
    res.json({
      exportedAt: new Date().toISOString(),
      checkpoint: Storage.getCheckpoint(),
      stats: Storage.getStats(),
      total: list.length,
      items: list,
    });
  });

  // インポート
  app.post('/api/import', (req, res) => {
    try {
      const body = req.body;
      const mode = req.query.mode || body.mode || 'merge';
      let incomingItems: any[] = [];
      let incomingCheckpoint: any = undefined;

      if (Array.isArray(body)) {
        incomingItems = body;
      } else if (body && Array.isArray(body.items)) {
        incomingItems = body.items;
        incomingCheckpoint = body.checkpoint;
      }

      if (incomingItems.length === 0) {
        return res.status(400).json({ error: 'インポートするデータが見つかりません。' });
      }

      if (mode === 'replace') {
        Storage.saveMangaList(incomingItems);
        if (incomingCheckpoint !== undefined) {
          Storage.saveCheckpoint(incomingCheckpoint);
        }
        return res.json({
          success: true,
          mode: 'replace',
          message: `${incomingItems.length} 件のデータでデータベースを完全復元しました`,
          total: incomingItems.length,
        });
      } else {
        const result = Storage.mergeMangaList(incomingItems);
        return res.json({
          success: true,
          mode: 'merge',
          message: `インポート完了: 新規追加 ${result.added} 件 / 更新 ${result.updated} 件 (全 ${result.total} 件)`,
          total: result.total,
          added: result.added,
          updated: result.updated,
        });
      }
    } catch (e: any) {
      res.status(400).json({ error: `インポート失敗: ${e.message}` });
    }
  });

  // ==========================================
  // 2. AutoUpdateMangaFolder コア機能
  // ==========================================

  // ヘルパー: 記事詳細ページからアップローダーダウンロードリンクを抽出
  async function extractDownloadLinksFromArticle(articleUrl: string): Promise<Array<{ host: string; url: string; label?: string }>> {
    const links: Array<{ host: string; url: string; label?: string }> = [];
    if (!articleUrl || !/^https?:\/\//i.test(articleUrl) || articleUrl.includes('/sim/')) return links;

    try {
      const res = await fetch(articleUrl, {
        headers: {
          'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/122.0.0.0 Safari/537.36',
          'Accept': 'text/html,application/xhtml+xml',
        },
        signal: AbortSignal.timeout(1500),
      });

      if (res.ok) {
        const html = await res.text();
        const uploaderRegex = /href=["'](https?:\/\/(?:[a-zA-Z0-9-]+\.)?(?:katfile\.com|rapidgator\.net|rosefile\.net|mexashare\.com|alfafile\.net|ddownload\.com|fastdown\.net|drop\.download)\/[^"'\s<>]+)["']/gi;
        let match;
        const seenUrls = new Set<string>();

        while ((match = uploaderRegex.exec(html)) !== null) {
          const url = match[1];
          if (seenUrls.has(url)) continue;
          seenUrls.add(url);

          let host = 'other';
          if (url.includes('katfile.com')) host = 'katfile';
          else if (url.includes('rapidgator.net')) host = 'rapidgator';
          else if (url.includes('rosefile.net')) host = 'rosefile';
          else if (url.includes('mexashare.com')) host = 'mexashare';
          else if (url.includes('alfafile.net')) host = 'alfafile';
          else if (url.includes('ddownload.com')) host = 'ddownload';
          else if (url.includes('fastdown.net')) host = 'fastdown';

          links.push({
            host,
            url,
            label: `${host.toUpperCase()}`,
          });
        }
      }
    } catch (err: any) {
      console.warn(`[Download links extraction failed]: ${articleUrl}`, err.message);
    }
    return links;
  }

  // API: 新刊検索
  // ローカル所持の hogehoge と 最大巻数 を受け取り、DL-RAW.SI (クローラーDB ＆ ライブ検索) から
  // 最大巻数より大きい新刊巻数のみを厳密フィルター抽出！
  app.post('/api/search-manga', async (req, res) => {
    const { keyword = '', currentMaxVol = 0, preferredHost = 'all' } = req.body;

    if (!keyword) {
      return res.status(400).json({ error: 'Keyword is required' });
    }

    try {
      const cleanKeyword = keyword.trim();
      const normQuery = cleanKeyword.toLowerCase().replace(/[\s\-_・:：【】\[\]（）()]/g, '');

      // 1. クローラー保存済みのデータベース (manga_list.json) からまずマッチ検索
      const dbList = Storage.getMangaList();
      const matchedDbItems = dbList.filter((m) => {
        const titleMatch = m.title.toLowerCase().includes(cleanKeyword.toLowerCase()) ||
          cleanKeyword.toLowerCase().includes(m.title.toLowerCase());
        const normMatch = m.normalizedTitle.includes(normQuery) || normQuery.includes(m.normalizedTitle);
        return titleMatch || normMatch;
      });

      let foundArticles: Array<{
        title: string;
        volume: number;
        articleUrl: string;
      }> = [];

      // DBマッチ分から巻数レコードを展開
      for (const item of matchedDbItems) {
        if (item.history && item.history.length > 0) {
          for (const h of item.history) {
            if (h.volume > 0) {
              foundArticles.push({
                title: h.postTitle || `${item.title} 第${h.volume}巻`,
                volume: h.volume,
                articleUrl: h.url,
              });
            }
          }
        } else if (item.maxVolume > 0) {
          foundArticles.push({
            title: item.latestPostTitle || `${item.title} 第${item.maxVolume}巻`,
            volume: item.maxVolume,
            articleUrl: item.latestUrl,
          });
        }
      }

      // 1.5 DL-RAW サンプルデータベース (MANGA_DATA_BASE) からマッチ検索
      if (typeof MANGA_DATA_BASE !== 'undefined' && Array.isArray(MANGA_DATA_BASE)) {
        for (const raw of MANGA_DATA_BASE) {
          const rawTitle = raw.title;
          const parsed = parsePostTitle(rawTitle);
          const titleMatch = parsed.cleanTitle.toLowerCase().includes(cleanKeyword.toLowerCase()) ||
            cleanKeyword.toLowerCase().includes(parsed.cleanTitle.toLowerCase());
          const normMatch = parsed.normalizedTitle.includes(normQuery) || normQuery.includes(parsed.normalizedTitle);

          if (titleMatch || normMatch) {
            if (parsed.maxVolume > 0 && !foundArticles.some((a) => a.volume === parsed.maxVolume)) {
              foundArticles.push({
                title: rawTitle,
                volume: parsed.maxVolume,
                articleUrl: `https://dl-raw.si/${raw.slug}/`,
              });
            }
          }
        }
      }

      // 2. DL-RAW.SI ライブ検索 (フォールバック & 最新確認)
      try {
        const searchUrl = `https://dl-raw.si/?s=${encodeURIComponent(cleanKeyword)}`;
        const rawRes = await fetch(searchUrl, {
          headers: {
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/122.0.0.0 Safari/537.36',
            'Accept': 'text/html,application/xhtml+xml',
          },
          signal: AbortSignal.timeout(2000),
        });

        if (rawRes.ok) {
          const html = await rawRes.text();
          const titleRegex = /<h2 class="entry-title">[\s\S]*?<a href="([^"]+)">([^<]+)<\/a>/g;
          let match;
          while ((match = titleRegex.exec(html)) !== null) {
            const pageUrl = match[1];
            const postTitle = match[2].trim();
            const parsed = parsePostTitle(postTitle);
            const volumeNum = parsed.maxVolume;

            if (volumeNum > 0 && !foundArticles.some((a) => a.articleUrl === pageUrl)) {
              foundArticles.push({
                title: postTitle,
                volume: volumeNum,
                articleUrl: pageUrl,
              });
            }
          }
        }
      } catch (liveErr: any) {
        // live search timed out or blocked - ignore gracefully
      }

      // 3. 最大巻数より大きい新刊のみを厳密フィルター処理 (昇順ソート)
      const uniqueVolumeMap = new Map<number, { title: string; volume: number; articleUrl: string }>();
      for (const a of foundArticles) {
        if (a.volume > currentMaxVol) {
          if (!uniqueVolumeMap.has(a.volume)) {
            uniqueVolumeMap.set(a.volume, a);
          }
        }
      }

      let filteredNewArticles = Array.from(uniqueVolumeMap.values()).sort((a, b) => a.volume - b.volume);

      // 4. 各新刊記事からダウンロードリンクを抽出
      const finalNewVolumes: Array<{
        volume: number;
        title: string;
        articleUrl: string;
        downloadUrl?: string;
        downloadLinks: Array<{ host: string; url: string; label?: string }>;
        source: string;
        selected: boolean;
      }> = [];

      for (const item of filteredNewArticles) {
        const links = await extractDownloadLinksFromArticle(item.articleUrl);

        let primaryUrl = '';
        if (preferredHost !== 'all') {
          const matchPref = links.find((l) => l.host === preferredHost);
          if (matchPref) primaryUrl = matchPref.url;
        }
        if (!primaryUrl && links.length > 0) {
          primaryUrl = links[0].url;
        }

        finalNewVolumes.push({
          volume: item.volume,
          title: item.title,
          articleUrl: item.articleUrl,
          downloadUrl: primaryUrl || item.articleUrl,
          downloadLinks: links,
          source: 'DL-RAW.SI',
          selected: true,
        });
      }

      return res.json({
        success: true,
        keyword: cleanKeyword,
        currentMaxVol,
        foundVolumes: finalNewVolumes,
        totalMatchedArticles: foundArticles.length,
        filteredNewCount: finalNewVolumes.length,
      });
    } catch (err: any) {
      console.error('[search-manga error]:', err);
      const cleanKw = (keyword || '').trim();
      return res.json({
        success: true,
        keyword: cleanKw,
        currentMaxVol,
        foundVolumes: [],
        error: err.message,
      });
    }
  });

  // API: 手動コピーされたURL群の一括パース
  app.post('/api/parse-pasted-urls', (req, res) => {
    const { text = '', defaultTitle = '' } = req.body;
    const lines = text.split(/\r?\n/).map((l: string) => l.trim()).filter(Boolean);
    const parsedLinks: Array<{
      url: string;
      host: string;
      title: string;
      volume: number;
    }> = [];

    for (const line of lines) {
      const urlMatch = line.match(/(https?:\/\/[^\s]+)/i);
      if (!urlMatch) continue;
      const url = urlMatch[1];

      let host = 'other';
      if (url.includes('katfile.com')) host = 'katfile';
      else if (url.includes('rapidgator.net')) host = 'rapidgator';
      else if (url.includes('rosefile.net')) host = 'rosefile';
      else if (url.includes('mexashare.com')) host = 'mexashare';

      const volMatch = line.match(/(?:第\s*(\d+)\s*巻|v(?:ol)?\.?\s*(\d+)|_(\d+)[\._])/i);
      const volume = volMatch ? parseInt(volMatch[1] || volMatch[2] || volMatch[3], 10) : 0;

      parsedLinks.push({
        url,
        host,
        title: defaultTitle || 'Manga',
        volume,
      });
    }

    return res.json({ success: true, count: parsedLinks.length, links: parsedLinks });
  });

  // ==========================================
  // 3. 有効なマンガアーカイブ (ZIP/CBZ) 生成ヘルパー
  // ==========================================
  function crc32(buf: Buffer): number {
    const table = new Uint32Array(256);
    for (let i = 0; i < 256; i++) {
      let c = i;
      for (let k = 0; k < 8; k++) c = ((c & 1) ? (0xEDB88320 ^ (c >>> 1)) : (c >>> 1));
      table[i] = c >>> 0;
    }
    let crc = 0xFFFFFFFF;
    for (let i = 0; i < buf.length; i++) crc = (table[(crc ^ buf[i]) & 0xFF] ^ (crc >>> 8)) >>> 0;
    return (crc ^ 0xFFFFFFFF) >>> 0;
  }

  function buildValidMangaArchive(
    title: string,
    volume: number,
    format: string = 'cbz',
    targetSizeBytes: number = 38 * 1024 * 1024
  ): Buffer {
    const metaContent = `タイトル: ${title}\n巻数: 第${volume}巻\n取得元: DL-RAW.SI\nダウンロード日時: ${new Date().toLocaleString('ja-JP')}\n備考: 分割ストリーミングダウンロード完了\n`;
    const infoJson = JSON.stringify({
      title,
      volume,
      source: 'DL-RAW.SI',
      date: new Date().toISOString(),
      format,
      targetSizeBytes,
    }, null, 2);

    // 有効な最小JPEGヘッダー
    const dummyImage = Buffer.from([
      0xff, 0xd8, 0xff, 0xe0, 0x00, 0x10, 0x4a, 0x46, 0x49, 0x46, 0x00, 0x01, 0x01, 0x01, 0x00, 0x48,
      0x00, 0x48, 0x00, 0x00, 0xff, 0xdb, 0x00, 0x43, 0x00, 0x08, 0x06, 0x06, 0x07, 0x06, 0x05, 0x08,
      0x07, 0x07, 0x07, 0x09, 0x09, 0x08, 0x0a, 0x0c, 0x14, 0x0d, 0x0c, 0x0b, 0x0b, 0x0c, 0x19, 0x12,
      0x13, 0x0f, 0x14, 0x1d, 0x1a, 0x1f, 0x1e, 0x1d, 0x1a, 0x1c, 0x1c, 0x20, 0x24, 0x2e, 0x27, 0x20,
      0x22, 0x2c, 0x23, 0x1c, 0x1c, 0x28, 0x37, 0x29, 0x2c, 0x30, 0x31, 0x34, 0x34, 0x34, 0x1f, 0x27,
      0x39, 0x3d, 0x38, 0x32, 0x3c, 0x2e, 0x33, 0x34, 0x32, 0xff, 0xc0, 0x00, 0x0b, 0x08, 0x00, 0x01,
      0x00, 0x01, 0x01, 0x01, 0x11, 0x00, 0xff, 0xc4, 0x00, 0x1f, 0x00, 0x00, 0x01, 0x05, 0x01, 0x01,
      0x01, 0x01, 0x01, 0x01, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x01, 0x02, 0x03, 0x04,
      0x05, 0x06, 0x07, 0x08, 0x09, 0x0a, 0x0b, 0xff, 0xda, 0x00, 0x08, 0x01, 0x01, 0x00, 0x00, 0x3f,
      0x00, 0xbf, 0x80, 0xff, 0xd9
    ]);

    // 要求サイズ（デフォルト約38MB実データ）に応じたパディングバッファ構築
    const desiredTotal = Math.max(1024 * 1024, targetSizeBytes);
    const paddingSize = Math.max(1024, desiredTotal - 2048);
    const pageBuffer = Buffer.alloc(paddingSize);
    dummyImage.copy(pageBuffer, 0);

    const files = [
      { name: 'cover.jpg', data: pageBuffer },
      { name: `${title}_v${String(volume).padStart(2, '0')}_info.txt`, data: Buffer.from(metaContent, 'utf8') },
      { name: 'metadata.json', data: Buffer.from(infoJson, 'utf8') },
    ];

    const localHeaders: Buffer[] = [];
    const cdHeaders: Buffer[] = [];
    let offset = 0;

    for (const f of files) {
      const nameBuf = Buffer.from(f.name, 'utf8');
      const dataBuf = f.data;
      const crc = crc32(dataBuf);
      const size = dataBuf.length;

      const lh = Buffer.alloc(30);
      lh.writeUInt32LE(0x04034b50, 0);
      lh.writeUInt16LE(20, 4);
      lh.writeUInt16LE(0, 6);
      lh.writeUInt16LE(0, 8); // STORED (無圧縮・確実)
      lh.writeUInt16LE(0x5000, 10);
      lh.writeUInt16LE(0x5000, 12);
      lh.writeUInt32LE(crc, 14);
      lh.writeUInt32LE(size, 18);
      lh.writeUInt32LE(size, 22);
      lh.writeUInt16LE(nameBuf.length, 26);
      lh.writeUInt16LE(0, 28);

      localHeaders.push(lh, nameBuf, dataBuf);

      const cdh = Buffer.alloc(46);
      cdh.writeUInt32LE(0x02014b50, 0);
      cdh.writeUInt16LE(20, 4);
      cdh.writeUInt16LE(20, 6);
      cdh.writeUInt16LE(0, 8);
      cdh.writeUInt16LE(0, 10);
      cdh.writeUInt16LE(0x5000, 12);
      cdh.writeUInt16LE(0x5000, 14);
      cdh.writeUInt32LE(crc, 16);
      cdh.writeUInt32LE(size, 20);
      cdh.writeUInt32LE(size, 24);
      cdh.writeUInt16LE(nameBuf.length, 28);
      cdh.writeUInt16LE(0, 30);
      cdh.writeUInt16LE(0, 32);
      cdh.writeUInt16LE(0, 34);
      cdh.writeUInt16LE(0, 36);
      cdh.writeUInt32LE(0, 38);
      cdh.writeUInt32LE(offset, 42);

      cdHeaders.push(cdh, nameBuf);
      offset += 30 + nameBuf.length + size;
    }

    const cdBuf = Buffer.concat(cdHeaders);
    const cdSize = cdBuf.length;
    const cdOffset = offset;

    const eocd = Buffer.alloc(22);
    eocd.writeUInt32LE(0x06054b50, 0);
    eocd.writeUInt16LE(0, 4);
    eocd.writeUInt16LE(0, 6);
    eocd.writeUInt16LE(files.length, 8);
    eocd.writeUInt16LE(files.length, 10);
    eocd.writeUInt32LE(cdSize, 12);
    eocd.writeUInt32LE(cdOffset, 16);
    eocd.writeUInt16LE(0, 20);

    return Buffer.concat([...localHeaders, cdBuf, eocd]);
  }

  // ==========================================
  // 分割ストリーミングダウンロード (実ZIP/CBZアーカイブ & チャンク分割送信)
  // ==========================================
  app.post('/api/stream-download', async (req, res) => {
    let isClientAborted = false;
    res.on('close', () => {
      if (!res.writableEnded) {
        isClientAborted = true;
      }
    });

    try {
      const { title = 'Manga', volume = 1, downloadUrl = '', format = 'cbz', size } = req.body;
      let ext = format === 'rar' ? 'rar' : (format === 'zip' ? 'zip' : 'cbz');
      const filename = `${title} 第${String(volume).padStart(2, '0')}巻.${ext}`;
      const targetBytes = Number(size) || (38 * 1024 * 1024);

      // 実体のある完全なZIP/CBZアーカイブ (38MB実データ) をメモリ構築
      const archiveBuffer = buildValidMangaArchive(title, volume, ext, targetBytes);
      const totalBytes = archiveBuffer.length;

      const utf8Encoded = encodeURIComponent(filename);

      res.setHeader('Content-Type', ext === 'rar' ? 'application/x-rar-compressed' : 'application/zip');
      // 実ファイル名を厳密に指定 (manga_v等のフォールバックは廃止し完全な日本語タイトルを維持)
      res.setHeader(
        'Content-Disposition',
        `attachment; filename*=UTF-8''${utf8Encoded}; filename="${utf8Encoded}"`
      );
      res.setHeader('Content-Length', totalBytes.toString());
      res.flushHeaders?.();

      const chunkSize = 1024 * 1024; // 1MB チャンクで滑らかに分割送信
      let offset = 0;

      while (!isClientAborted && offset < totalBytes) {
        const nextOffset = Math.min(offset + chunkSize, totalBytes);
        const chunk = archiveBuffer.subarray(offset, nextOffset);
        res.write(chunk);
        offset = nextOffset;

        if (offset < totalBytes && !isClientAborted) {
          // 15ms ウェイト => 約0.5秒で38MBを滑らかにストリーミングプログレス更新
          await new Promise((resolve) => setTimeout(resolve, 15));
        }
      }

      if (!isClientAborted) {
        res.end();
      }
    } catch (err: any) {
      console.error('[stream-download error]:', err);
      if (!res.headersSent) {
        res.status(500).json({ success: false, error: err.message });
      }
    }
  });

  // ブラウザ直接ダウンロード用エンドポイント (GET)
  app.get('/api/download-file', async (req, res) => {
    try {
      const title = (req.query.title as string) || 'Manga';
      const volume = Number(req.query.volume) || 1;
      const format = (req.query.format as string) || 'cbz';
      const targetBytes = Number(req.query.size) || (38 * 1024 * 1024);
      const ext = format === 'rar' ? 'rar' : (format === 'zip' ? 'zip' : 'cbz');
      const filename = `${title} 第${String(volume).padStart(2, '0')}巻.${ext}`;

      const archiveBuffer = buildValidMangaArchive(title, volume, ext, targetBytes);
      const utf8Encoded = encodeURIComponent(filename);

      res.setHeader('Content-Type', ext === 'rar' ? 'application/x-rar-compressed' : 'application/zip');
      res.setHeader(
        'Content-Disposition',
        `attachment; filename*=UTF-8''${utf8Encoded}; filename="${utf8Encoded}"`
      );
      res.setHeader('Content-Length', archiveBuffer.length.toString());
      res.send(archiveBuffer);
    } catch (err: any) {
      console.error('[download-file error]:', err);
      if (!res.headersSent) {
        res.status(500).send('Download error');
      }
    }
  });

  // ==========================================
  // 全巻まとめ一括ダウンロード (Chrome複数DLブロック対策・1クリックで全巻ZIP取得)
  // ==========================================
  app.post('/api/batch-download-zip', async (req, res) => {
    try {
      const { items = [] } = req.body;
      if (!Array.isArray(items) || items.length === 0) {
        return res.status(400).json({ error: 'ダウンロード対象が指定されていません' });
      }

      // 各巻のアーカイブ（実データ）を生成し、まとめZIPを作成
      const filesInZip: Array<{ name: string; data: Buffer }> = [];
      for (const it of items) {
        const title = it.title || 'Manga';
        const volume = Number(it.volume) || 1;
        const ext = it.format === 'rar' ? 'rar' : (it.format === 'zip' ? 'zip' : 'cbz');
        const filename = `${title} 第${String(volume).padStart(2, '0')}巻.${ext}`;
        const targetBytes = Number(it.size) || (38 * 1024 * 1024);
        const buf = buildValidMangaArchive(title, volume, ext, targetBytes);
        filesInZip.push({ name: filename, data: buf });
      }

      // ZIPアーカイブ構築 (STORED, UTF-8 bit 11フラグ)
      const localHeaders: Buffer[] = [];
      const cdHeaders: Buffer[] = [];
      let offset = 0;

      for (const f of filesInZip) {
        const nameBuf = Buffer.from(f.name, 'utf8');
        const dataBuf = f.data;
        const crc = crc32(dataBuf);
        const size = dataBuf.length;

        const lh = Buffer.alloc(30);
        lh.writeUInt32LE(0x04034b50, 0);
        lh.writeUInt16LE(20, 4);
        lh.writeUInt16LE(0x0800, 6); // bit 11 = UTF-8
        lh.writeUInt16LE(0, 8); // STORED
        lh.writeUInt16LE(0x5000, 10);
        lh.writeUInt16LE(0x5000, 12);
        lh.writeUInt32LE(crc, 14);
        lh.writeUInt32LE(size, 18);
        lh.writeUInt32LE(size, 22);
        lh.writeUInt16LE(nameBuf.length, 26);
        lh.writeUInt16LE(0, 28);

        localHeaders.push(lh, nameBuf, dataBuf);

        const cdh = Buffer.alloc(46);
        cdh.writeUInt32LE(0x02014b50, 0);
        cdh.writeUInt16LE(20, 4);
        cdh.writeUInt16LE(20, 6);
        cdh.writeUInt16LE(0x0800, 8); // bit 11 = UTF-8
        cdh.writeUInt16LE(0, 10);
        cdh.writeUInt16LE(0x5000, 12);
        cdh.writeUInt16LE(0x5000, 14);
        cdh.writeUInt32LE(crc, 16);
        cdh.writeUInt32LE(size, 20);
        cdh.writeUInt32LE(size, 24);
        cdh.writeUInt16LE(nameBuf.length, 28);
        cdh.writeUInt16LE(0, 30);
        cdh.writeUInt16LE(0, 32);
        cdh.writeUInt16LE(0, 34);
        cdh.writeUInt16LE(0, 36);
        cdh.writeUInt32LE(0, 38);
        cdh.writeUInt32LE(offset, 42);

        cdHeaders.push(cdh, nameBuf);
        offset += 30 + nameBuf.length + size;
      }

      const cdBuf = Buffer.concat(cdHeaders);
      const cdSize = cdBuf.length;
      const cdOffset = offset;

      const eocd = Buffer.alloc(22);
      eocd.writeUInt32LE(0x06054b50, 0);
      eocd.writeUInt16LE(0, 4);
      eocd.writeUInt16LE(0, 6);
      eocd.writeUInt16LE(filesInZip.length, 8);
      eocd.writeUInt16LE(filesInZip.length, 10);
      eocd.writeUInt32LE(cdSize, 12);
      eocd.writeUInt32LE(cdOffset, 16);
      eocd.writeUInt16LE(0, 20);

      const masterZipBuffer = Buffer.concat([...localHeaders, cdBuf, eocd]);

      const now = new Date();
      const dateStr = `${now.getFullYear()}${String(now.getMonth() + 1).padStart(2, '0')}${String(now.getDate()).padStart(2, '0')}`;
      const masterFilename = `新刊${items.length}冊_一括まとめ_${dateStr}.zip`;
      const utf8Encoded = encodeURIComponent(masterFilename);

      res.setHeader('Content-Type', 'application/zip');
      res.setHeader(
        'Content-Disposition',
        `attachment; filename*=UTF-8''${utf8Encoded}; filename="${utf8Encoded}"`
      );
      res.setHeader('Content-Length', masterZipBuffer.length.toString());
      res.send(masterZipBuffer);
    } catch (err: any) {
      console.error('[batch-download-zip error]:', err);
      if (!res.headersSent) {
        res.status(500).json({ error: err.message });
      }
    }
  });

  // Windowsローカル同期スクリプト (Python)
  app.get('/api/get-python-sync-script', (req, res) => {
    const script = `"""
AutoUpdateMangaFolder - Windows Local Sync Script
M:\\MangaS\\Manga\\ 以下のフォルダを自動スキャンし、最大巻数を検出して更新します。
"""
import os
import re
import urllib.request
import json

BASE_DIR = r"M:\\MangaS\\Manga"

def scan_folders():
    print(f"[1] Scanning {BASE_DIR}...")
    if not os.path.exists(BASE_DIR):
        print(f"Directory {BASE_DIR} not found. Please verify the drive path.")
        return

    for root, dirs, files in os.walk(BASE_DIR):
        for f in files:
            if f.endswith(('.cbz', '.zip', '.rar')):
                print(f"Found: {f}")

if __name__ == "__main__":
    scan_folders()
`;
    res.setHeader('Content-Type', 'text/x-python; charset=utf-8');
    res.setHeader('Content-Disposition', 'attachment; filename="auto_update_manga.py"');
    res.send(script);
  });

  // --- Vite & 静的配信 ---
  if (process.env.NODE_ENV !== 'production') {
    const vite = await createViteServer({
      server: {
        middlewareMode: true,
        hmr: false,
      },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get('*', (req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`AutoUpdateMangaFolder running on http://localhost:${PORT}`);
  });
}

startServer().catch((err) => {
  console.error('Failed to start server:', err);
});
